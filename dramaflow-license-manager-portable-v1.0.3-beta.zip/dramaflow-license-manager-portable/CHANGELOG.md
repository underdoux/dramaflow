# DramaFlow License Manager Portable Changelog

## [1.0.3] - 2026-11-09
- Hardened admin token persistence and bearer-token validation.
- Added no-cache handling and clearer API response diagnostics.
- Dashboard no longer silently logs out on every API error; it displays the failure.


## [1.0.2] - 2026-11-09
- Hardened admin password hashing and case-sensitive comparison.
- Added password reset utility that preserves licenses and activations.
- Reset invalidated admin sessions after password changes.


## [1.0.1] - 2026-11-09
- Fixed REST route handling for heartbeat/deactivation.
- Fixed domain/product activation removal and invalid license ID handling.
- Replaced implicit browser global references in the dashboard form.

# DramaFlow Changelog

Riwayat versi resmi theme dan core plugin DramaFlow.

## [2.4.0] - 2026-11-09
### Added
- Windows 11 portable License Manager using built-in PowerShell and local JSON storage.
- Web dashboard with license creation, domain allowlists, activation monitoring, status control and event log.
- Public client activation and heartbeat endpoints compatible with DramaFlow WordPress products.
- Theme and Core Plugin schedule 12-hour online heartbeat after successful online activation.
- Cloudflare Tunnel setup files and portable deployment documentation.
### Notes
- This is a beta portable build; requires live Windows/WordPress testing before production.
- Dashboard is password protected; API endpoints use license-key validation and domain allowlists. Put dashboard behind Cloudflare Access while bypassing the client API path.
- The PC must remain powered on and connected for live monitoring. Missed heartbeat is shown as offline after 36 hours.
- Portable manager stores data in JSON; back up `data/licenses.json`.
- PowerShell/Windows Firewall, Cloudflare Tunnel and hostname routing need configuration by the owner.

## [2.3.0] - 2026-11-09
### Added
- Separate self-hosted WordPress License Server plugin with license issuance and activation monitoring.
- Online activation mode option in DramaFlow Theme and Core License pages.
- Domain allowlist per serial, product-specific licenses, expiry and server-side disable status.
- Complete installation, operations, and license-system documentation bundled in release archives.
### Notes
- Online client activation contacts the License Server; periodic automatic revalidation and complete feature lockout are not implemented yet.
- Online revocation may not immediately stop an already activated site until it contacts the server again.
- End-to-end testing on a live WordPress installation is still required.

## [2.2.0] - 2026-11-09
### Added
- Offline signed serial activation for DramaFlow Theme and DramaFlow Core Plugin.
- RSA/SHA-256 signature verification using an embedded public key; private signing key is isolated in the separate generator package.
- Domain-bound licenses, optional expiry date, product separation, and activation status notices/pages in WordPress admin.
- Separate local PHP serial generator application.
### Security and limitations
- Keep the generator and `private.pem` offline and private; never upload them to the public WordPress site.
- Offline licenses cannot be remotely revoked, centrally counted, or automatically transferred between domains.
- Generate one license per product and domain. A theme serial cannot activate the core plugin, and vice versa.
- This release provides activation status and signed verification; it does not disable all front-end/theme functionality when unlicensed.
- Change the generator's default password before use.

## [2.1.0] - 2026-11-09
### Added
- Demo Data & Import admin page under DramaFlow.
- One-click installation of fictional sample drama and episode content, without duplicate drama titles.
- JSON upload importer for custom drama/episode data; imported items are created as drafts for review.
- Included `sample-drama-import.json` as an editable import template.
### Notes
- Demo content contains fictional descriptions and no licensed poster/video assets.
- Video URLs must be supplied by the site owner with proper usage rights.
- JSON importer currently supports drama title, synopsis, year, country, genres, and episode title/number/video URL.

## [2.0.0] - 2026-11-09
### Added
- Search Console page-level performance report: clicks, impressions, CTR, average position.
- Page prioritization using transparent heuristics for high impressions/low CTR and positions 4–20.
- Affiliate click opportunity report grouped by referring page for the last 30 days.
- Flexible Search Console dimensions in the internal query helper.
### Fixed
- Added schema version check and dbDelta migration on admin load, so existing installations can update the affiliate tracking table after plugin upgrades.
### Notes
- Affiliate report measures tracked clicks, not purchases, revenue, or commissions.
- SEO priority labels are heuristic indicators, not ranking guarantees.
- Search Console API and WordPress runtime still need validation on the target site.

## [1.9.0] - 2026-11-09
### Added
- SEO opportunity suggestions based on Google Search Console query performance.
- Heuristic flags for high-impression/low-CTR queries, ranking positions around 4–20, and low-visibility queries.
- Editorial action suggestions; no content is changed automatically.

## [1.8.0]
### Added
- Google OAuth connection flow for Search Console.
- Search Console property listing and query performance retrieval.
- Query metrics: clicks, impressions, CTR, average position.
- Token refresh and disconnect controls.

## [1.7.0]
### Added
- SEO Assistant draft SEO title and meta description based on drama metadata.
- Explicit admin approval before applying suggested metadata.

## [1.6.0]
### Added
- GA4 Measurement ID configuration and affiliate_click event.
- Search Console verification meta tag configuration.
- SEO metadata completeness audit.

## [1.5.0]
### Added
- Affiliate campaign impression and click counters.
- CTR reporting and campaign rotation by recorded impressions.

## [1.4.0]
### Added
- Genre and country catalog filters and taxonomy templates.
- Per-drama SEO title and meta description fields.

## [1.3.0]
### Added
- HLS.js playback, optional video quality sources, WebVTT subtitles, previous/next episode navigation.

## [1.2.0]
### Added
- Affiliate campaign management, episode targeting, scheduling, click tracking.

## [1.1.0]
### Added
- Initial independent DramaFlow theme and core plugin.
- Dark responsive OTT catalog, Drama/Episode post types, Genre/Country taxonomies, player overlay.

## [1.0.0]
### Foundation
- Initial project baseline and standalone theme/core-plugin architecture.

## Known limitations
- Search Console suggestions are threshold-based, not AI keyword research or search-volume estimates.
- GSC property selection falls back to the first accessible property if homepage URL matching fails.
- GA4 does not yet provide a Data API reporting dashboard; consent management must be configured separately.
- Affiliate impressions are logged when ad markup is rendered, not confirmed viewable impressions.
- Affiliate click counts do not prove marketplace purchases or commissions.
- HLS.js is loaded from a CDN; HLS adaptive behavior depends on the manifest and browser.
- OAuth, API, and front-end behavior require testing on the target WordPress hosting environment.
