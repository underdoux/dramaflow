@echo off
where cloudflared.exe >nul 2>nul
if errorlevel 1 (
  echo cloudflared.exe tidak ditemukan. Download dari https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
  pause
  exit /b 1
)
cloudflared.exe tunnel run dramaflow-license
pause
