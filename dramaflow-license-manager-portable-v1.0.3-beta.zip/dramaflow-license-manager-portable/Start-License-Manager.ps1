# DramaFlow License Manager Portable - Windows 11 / PowerShell 5.1+
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir = Join-Path $Root "data"
$DbFile = Join-Path $DataDir "licenses.json"
$Port = 8787
$HostName = "http://127.0.0.1:$Port/"
if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir | Out-Null }
if (!(Test-Path $DbFile)) {
  $initial = @{ licenses=@(); activations=@(); events=@(); adminPasswordHash=""; token="" }
  $initial | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $DbFile
}
function Read-Db { $raw=Get-Content -Raw -Encoding UTF8 $DbFile; if(!$raw.Trim()){return @{licenses=@();activations=@();events=@();adminPasswordHash="";token=""}}; return ($raw | ConvertFrom-Json) }
function Write-Db($db) { $db | ConvertTo-Json -Depth 30 | Set-Content -Encoding UTF8 $DbFile }
function Sha($s) { $b=[Text.Encoding]::UTF8.GetBytes([string]$s); $h=[Security.Cryptography.SHA256]::Create().ComputeHash($b); return ([BitConverter]::ToString($h)).Replace("-","").ToLower() }
function Json($obj,$status=200) { $script:Response.StatusCode=$status; $script:Response.ContentType="application/json; charset=utf-8"; $bytes=[Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Depth 20 -Compress)); $script:Response.OutputStream.Write($bytes,0,$bytes.Length) }
function Read-Body { $r=New-Object IO.StreamReader($script:Request.InputStream,$script:Request.ContentEncoding); $s=$r.ReadToEnd();$r.Close(); if(!$s){return @{}}; return ($s | ConvertFrom-Json) }
function Normalize-Domain($d) { $v=([string]$d).Trim().ToLower() -replace '^https?://','';$v=$v.Split('/')[0] -replace '^www\.',''; return $v }
function Add-Event($db,$type,$domain,$product,$note) { $db.events=@(@{time=(Get-Date).ToUniversalTime().ToString("o");type=$type;domain=$domain;product=$product;note=$note}) + @($db.events | Select-Object -First 499) }
function Send-AdminPage {
$html=@'
<!doctype html><html lang="id"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DramaFlow License Manager</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1018;color:#eef2f7;font:14px Segoe UI,Arial}header{padding:20px 28px;background:#111a27;border-bottom:1px solid #263448;display:flex;justify-content:space-between;align-items:center}h1{font-size:21px;margin:0}main{max-width:1200px;margin:25px auto;padding:0 18px}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.card,.panel{background:#131d2b;border:1px solid #263448;border-radius:12px;padding:17px}.num{font-size:28px;font-weight:700;margin-top:6px}.muted{color:#9eacbf}.green{color:#50d890}.red{color:#ff707b}.yellow{color:#ffc76a}button{background:#e50914;color:white;border:0;padding:10px 15px;border-radius:7px;cursor:pointer;font-weight:600}input,select,textarea{background:#0c1420;color:white;border:1px solid #33445b;border-radius:7px;padding:10px;width:100%;margin:5px 0 12px}label{display:block;color:#bdc9d8}.row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}.panel{margin-top:18px;overflow:auto}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{text-align:left;padding:11px;border-bottom:1px solid #263448;vertical-align:top}th{color:#aebbd0}.pill{padding:4px 8px;border-radius:20px;background:#24344a}.actions{display:flex;gap:7px;align-items:center}.secondary{background:#33445b}.hide{display:none}.login{max-width:420px;margin:12vh auto}.toast{padding:12px;background:#24344a;border-radius:8px;margin:12px 0;white-space:pre-wrap}@media(max-width:700px){.cards{grid-template-columns:1fr 1fr}.row{grid-template-columns:1fr}header{padding:16px}}
</style><header><h1>▶ DramaFlow License Manager</h1><button class="secondary" onclick="logout()">Keluar</button></header><main>
<div id="login" class="panel login"><h2>Login Admin</h2><label>Password admin</label><input id="pw" type="password"><button onclick="login()">Masuk</button><div id="loginmsg" class="muted"></div></div>
<div id="app" class="hide">
<div class="cards"><div class="card"><div class="muted">Total Lisensi</div><div id="total" class="num">0</div></div><div class="card"><div class="muted">Domain Online</div><div id="online" class="num green">0</div></div><div class="card"><div class="muted">Domain Offline</div><div id="offline" class="num yellow">0</div></div><div class="card"><div class="muted">Lisensi Diblokir</div><div id="blocked" class="num red">0</div></div></div>
<div class="panel"><h2>Buat Serial Online</h2><div class="row"><div><label>Produk</label><select id="product"><option value="theme">DramaFlow Theme</option><option value="core">DramaFlow Core Plugin</option></select></div><div><label>Domain diizinkan (pisahkan koma)</label><input id="domains" placeholder="site-a.com, site-b.com"></div><div><label>Kedaluwarsa (opsional)</label><input id="expires" type="date"></div></div><button onclick="createLicense()">Buat Serial</button><div id="newkey"></div><div id="msg" class="toast hide"></div></div>
<div class="panel"><h2>Website & Aktivasi</h2><input id="filter" placeholder="Cari domain..." oninput="render()"><table><thead><tr><th>Domain</th><th>Produk</th><th>Versi</th><th>Status koneksi</th><th>Lisensi</th><th>Terakhir terlihat</th><th>Aksi</th></tr></thead><tbody id="sites"></tbody></table></div>
<div class="panel"><h2>Lisensi</h2><table><thead><tr><th>Serial</th><th>Produk</th><th>Domain diizinkan</th><th>Expiry</th><th>Status</th><th>Aksi</th></tr></thead><tbody id="licenses"></tbody></table></div>
<div class="panel"><h2>Aktivitas terbaru</h2><table><thead><tr><th>Waktu UTC</th><th>Aktivitas</th><th>Domain</th><th>Produk</th><th>Catatan</th></tr></thead><tbody id="events"></tbody></table></div>
</div></main><script>
let token=sessionStorage.getItem('dflm_token')||'';
async function api(path,data={}){let r=await fetch('/api/'+path,{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify(data)});let raw=await r.text();let j;try{j=JSON.parse(raw)}catch(e){throw Error('Respons server tidak valid ('+r.status+'): '+raw.slice(0,180))}if(!r.ok)throw Error(j.error||('Request gagal ('+r.status+')'));return j}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function login(){try{let x=await api('login',{password:document.getElementById('pw').value});token=x.token;sessionStorage.setItem('dflm_token',token);show();}catch(e){document.getElementById('loginmsg').innerText=e.message}}
function show(){document.getElementById('login').classList.add('hide');document.getElementById('app').classList.remove('hide');refresh()}
function logout(){sessionStorage.removeItem('dflm_token');location.reload()}
function message(s){let m=document.getElementById('msg');m.innerText=s;m.classList.remove('hide')}
async function createLicense(){try{let x=await api('create',{product:document.getElementById('product').value,domains:document.getElementById('domains').value,expires:document.getElementById('expires').value});document.getElementById('newkey').innerHTML='<div class="toast">Serial baru (salin sekarang):<br><b>'+esc(x.license_key)+'</b></div>';document.getElementById('domains').value='';message('Lisensi berhasil dibuat.');refresh()}catch(e){message(e.message)}}
async function action(id,status){try{await api('license-status',{id,status});refresh()}catch(e){alert(e.message)}}
async function refresh(){try{let d=await api('dashboard');document.getElementById('total').innerText=d.stats.licenses;document.getElementById('online').innerText=d.stats.online;document.getElementById('offline').innerText=d.stats.offline;document.getElementById('blocked').innerText=d.stats.blocked;window.data=d;render()}catch(e){message('Gagal memuat dashboard: '+e.message);document.getElementById('app').classList.remove('hide');document.getElementById('login').classList.add('hide');}}
function render(){if(!window.data)return;let q=document.getElementById('filter').value.toLowerCase();document.getElementById('sites').innerHTML=window.data.sites.filter(x=>x.domain.includes(q)).map(x=>`<tr><td>${esc(x.domain)}</td><td>${esc(x.product)}</td><td>${esc(x.version||'-')}</td><td><span class="pill ${x.online?'green':'yellow'}">${x.online?'Online':'Offline'}</span></td><td>${esc(x.license_status)}</td><td>${esc(x.last_seen||'-')}</td><td><button class="secondary" onclick="deactivate('${esc(x.domain)}','${esc(x.product)}')">Hapus aktivasi</button></td></tr>`).join('');
document.getElementById('licenses').innerHTML=window.data.licenses.map(x=>`<tr><td>••••${esc(x.hint)}</td><td>${esc(x.product)}</td><td>${esc(x.domains.join(', '))}</td><td>${esc(x.expires||'Tidak ada')}</td><td>${esc(x.status)}</td><td><button class="secondary" onclick="action('${x.id}','${x.status==='active'?'disabled':'active'}')">${x.status==='active'?'Blokir':'Aktifkan'}</button></td></tr>`).join('');
document.getElementById('events').innerHTML=window.data.events.slice(0,40).map(x=>`<tr><td>${esc(x.time)}</td><td>${esc(x.type)}</td><td>${esc(x.domain)}</td><td>${esc(x.product)}</td><td>${esc(x.note)}</td></tr>`).join('')}
async function deactivate(domain,product){if(!confirm('Hapus aktivasi '+domain+'?'))return;try{await api('deactivate-domain',{domain,product});refresh()}catch(e){alert(e.message)}}
if(token)show();setInterval(()=>{if(token)refresh()},60000);
</script></html>
'@
 $bytes=[Text.Encoding]::UTF8.GetBytes($html);$script:Response.ContentType="text/html; charset=utf-8";$script:Response.StatusCode=200;$script:Response.OutputStream.Write($bytes,0,$bytes.Length)
}
function Handle-Api {
 $path=$script:Request.Url.AbsolutePath.Trim('/')
 $body=Read-Body
 $db=Read-Db
 if($path -eq 'api/setup' -and $script:Request.HttpMethod -eq 'POST'){
   if($db.adminPasswordHash){Json @{error='Setup sudah selesai'} 409;return}
   if(([string]$body.password).Length -lt 14){Json @{error='Password minimal 14 karakter'} 400;return}
   $db.adminPasswordHash = Sha ([string]$body.password); $db.token = ''; Write-Db $db; Json @{success=$true}; return
 }
 if($path -eq 'api/login'){
   $submittedHash = Sha ([string]$body.password); if([string]::IsNullOrWhiteSpace([string]$db.adminPasswordHash) -or ($submittedHash -cne [string]$db.adminPasswordHash)){Json @{error='Password admin tidak cocok. Periksa huruf besar/kecil dan karakter O/0.'} 401;return}
   $newToken = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N'); $tokenHash = Sha ([string]$newToken); $db | Add-Member -MemberType NoteProperty -Name token -Value ([string]$tokenHash) -Force; Write-Db $db; Json @{token=[string]$newToken}; return
 }
 $publicLicenseRoute = $path -in @('api/activate','api/heartbeat','api/check','api/deactivate','wp-json/dramaflow-license/v1/activate','wp-json/dramaflow-license/v1/heartbeat','wp-json/dramaflow-license/v1/check','wp-json/dramaflow-license/v1/heartbeat','wp-json/dramaflow-license/v1/deactivate')
 if(!$publicLicenseRoute) {
  $auth=$script:Request.Headers['Authorization']
  $storedTokenHash = [string]$db.token; $providedTokenHash = ''; if($auth -and $auth -match '^Bearer\s+(.+)$'){ $providedTokenHash = Sha ([string]$Matches[1]) }; if([string]::IsNullOrWhiteSpace($storedTokenHash) -or [string]::IsNullOrWhiteSpace($providedTokenHash) -or ($providedTokenHash -cne $storedTokenHash)){Json @{error='Sesi admin tidak valid atau sudah berakhir. Silakan login ulang.'} 401;return}
 }
 switch($path){
  'api/create' {
   $product=[string]$body.product;if($product -notin @('theme','core')){Json @{error='Produk tidak valid'} 400;return}
   $domains=@(([string]$body.domains -split '[,;\r\n]')|%{Normalize-Domain $_}|?{$_ -match '^[a-z0-9.-]+\.[a-z]{2,}$'}|Select-Object -Unique)
   if(!$domains.Count){Json @{error='Masukkan minimal satu domain valid'} 400;return}
   $bytes=New-Object byte[] 20; $rng=[Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($bytes); $key='DFO-'+([BitConverter]::ToString($bytes)).Replace('-','')
   $id=[guid]::NewGuid().ToString('N')
   $db.licenses+=@{id=$id;hash=(Sha $key);hint=$key.Substring($key.Length-8);product=$product;domains=$domains;expires=[string]$body.expires;status='active';created=(Get-Date).ToUniversalTime().ToString('o')}
   Add-Event $db 'license_created' ($domains -join ', ') $product 'Serial dibuat';Write-Db $db;Json @{license_key=$key;id=$id};return
  }
  'api/activate' { $action='activate' }
  'wp-json/dramaflow-license/v1/activate' { $action='activate' }
  'api/heartbeat' { $action='heartbeat' }
  'wp-json/dramaflow-license/v1/heartbeat' { $action='heartbeat' }
  'api/check' { $action='check' }
  'wp-json/dramaflow-license/v1/check' { $action='check' }
  'api/deactivate' { $action='deactivate' }
  'wp-json/dramaflow-license/v1/deactivate' { $action='deactivate' }
  default {
   if($path -eq 'api/dashboard'){
    $sites=@($db.activations|%{$a=$_;$l=$db.licenses|?{$_.id -eq $a.licenseId}|select -First 1;[pscustomobject]@{domain=$a.domain;product=$a.product;version=$a.version;online=(([DateTime]::UtcNow-[DateTime]::Parse($a.lastSeen)).TotalHours -lt 36);last_seen=$a.lastSeen;license_status=if($l){$l.status}else{'missing'}}})
    Json @{stats=@{licenses=$db.licenses.Count;online=@($sites|? online).Count;offline=@($sites|? {-not $_.online}).Count;blocked=@($db.licenses|? status -eq 'disabled').Count};sites=$sites;licenses=@($db.licenses|%{[pscustomobject]@{id=$_.id;hint=$_.hint;product=$_.product;domains=$_.domains;expires=$_.expires;status=$_.status}});events=@($db.events)};return
   }
   if($path -eq 'api/license-status'){$l=$db.licenses|? id -eq $body.id|select -First 1;if(!$l){Json @{error='Lisensi tidak ditemukan'} 404;return};$l.status=if($body.status -eq 'disabled'){'disabled'}else{'active'};Add-Event $db 'license_status' ($l.domains -join ', ') $l.product $l.status;Write-Db $db;Json @{success=$true};return}
   if($path -eq 'api/deactivate-domain'){$domainToRemove=Normalize-Domain $body.domain;$db.activations=@($db.activations|Where-Object{-not ($_.domain -eq $domainToRemove -and $_.product -eq $body.product)});Add-Event $db 'domain_removed' $domainToRemove $body.product 'Aktivasi dihapus admin';Write-Db $db;Json @{success=$true};return}
   Json @{error='Not found'} 404;return
  }
 }
 $key=[string]$body.license_key;$product=[string]$body.product;$domain=Normalize-Domain $body.domain;$l=$db.licenses|?{$_.hash -eq (Sha $key) -and $_.product -eq $product}|select -First 1
 if(!$l -or $l.status -ne 'active'){Json @{error='Lisensi tidak aktif atau tidak ditemukan'} 403;return}
 if($l.expires -and $l.expires -lt (Get-Date).ToString('yyyy-MM-dd')){Json @{error='Lisensi kedaluwarsa'} 403;return}
 if($domain -notin $l.domains){Json @{error='Domain belum diizinkan'} 403;return}
 if($action -eq 'activate'){
  $a=$db.activations|?{$_.licenseId -eq $l.id -and $_.domain -eq $domain -and $_.product -eq $product}|select -First 1
  if(!$a){$a=@{licenseId=$l.id;domain=$domain;product=$product;version=[string]$body.version;activatedAt=(Get-Date).ToUniversalTime().ToString('o');lastSeen=(Get-Date).ToUniversalTime().ToString('o')};$db.activations+= $a}
  $a.lastSeen=(Get-Date).ToUniversalTime().ToString('o');$a.version=[string]$body.version;Add-Event $db 'activated' $domain $product 'Aktivasi berhasil'
 } elseif($action -eq 'heartbeat' -or $action -eq 'check'){
  $a=$db.activations|?{$_.licenseId -eq $l.id -and $_.domain -eq $domain -and $_.product -eq $product}|select -First 1
  if(!$a){Json @{error='Domain belum diaktivasi'} 403;return}
  $a.lastSeen=(Get-Date).ToUniversalTime().ToString('o');$a.version=[string]$body.version;Add-Event $db $action $domain $product 'Sinyal diterima'
 } elseif($action -eq 'deactivate'){$db.activations=@($db.activations|?{!($_.licenseId -eq $l.id -and $_.domain -eq $domain -and $_.product -eq $product)});Add-Event $db 'deactivated' $domain $product 'Website menonaktifkan lisensi'}
 Write-Db $db;Json @{success=$true;status='active';domain=$domain;product=$product}
}
Write-Host "DramaFlow License Manager Portable" -ForegroundColor Cyan
Write-Host "Local dashboard: $HostName"
$db=Read-Db
if(!$db.adminPasswordHash){
  Write-Host "Buat password admin pertama kali (minimal 14 karakter)." -ForegroundColor Yellow
  $p=Read-Host "Password admin"
  if($p.Length -lt 14){Write-Host "Password terlalu pendek.";exit}
  $db.adminPasswordHash = Sha ([string]$p); $db.token = ''; Write-Db $db
}
$listener=New-Object Net.HttpListener
$listener.Prefixes.Add($HostName)
try{$listener.Start()}catch{Write-Host "Gagal membuka port $Port. Jalankan sebagai user yang punya izin atau ubah port.";exit}
Start-Process $HostName
while($listener.IsListening){
 try{
  $ctx=$listener.GetContext();$script:Request=$ctx.Request;$script:Response=$ctx.Response
  try{
   if($script:Request.Url.AbsolutePath -eq '/' -and $script:Request.HttpMethod -eq 'GET'){Send-AdminPage}
   elseif($script:Request.Url.AbsolutePath -like '/api/*' -or $script:Request.Url.AbsolutePath -like '/wp-json/*'){Handle-Api}
   else{Json @{error='Not found'} 404}
  }catch{Json @{error=$_.Exception.Message} 500}
  $script:Response.OutputStream.Close()
 }catch{if($listener.IsListening){Write-Host $_}}
}
$listener.Stop()
