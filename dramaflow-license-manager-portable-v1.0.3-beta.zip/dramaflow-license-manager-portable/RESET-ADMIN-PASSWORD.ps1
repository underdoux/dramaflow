# Reset password admin DramaFlow License Manager tanpa menghapus data lisensi.
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DbFile = Join-Path (Join-Path $Root "data") "licenses.json"
if (!(Test-Path $DbFile)) {
  Write-Host "Database belum ada. Jalankan Start-License-Manager.ps1 terlebih dahulu." -ForegroundColor Red
  Read-Host "Tekan Enter untuk keluar"; exit 1
}
$plain = Read-Host "Masukkan password admin baru (minimal 14 karakter)"
if ($plain.Length -lt 14) {
  Write-Host "Password minimal 14 karakter." -ForegroundColor Red
  Read-Host "Tekan Enter untuk keluar"; exit 1
}
$db = Get-Content -Raw -Encoding UTF8 $DbFile | ConvertFrom-Json
$bytes = [Text.Encoding]::UTF8.GetBytes([string]$plain)
$sha = [Security.Cryptography.SHA256]::Create()
try { $hashBytes = $sha.ComputeHash($bytes) } finally { $sha.Dispose() }
$db.adminPasswordHash = ([BitConverter]::ToString($hashBytes)).Replace("-","").ToLowerInvariant()
$db.token = ""
$db | ConvertTo-Json -Depth 30 | Set-Content -Encoding UTF8 $DbFile
Write-Host "Password admin berhasil direset. Data lisensi dan aktivasi tetap aman." -ForegroundColor Green
Read-Host "Tekan Enter untuk keluar"
