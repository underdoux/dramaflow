@echo off
 echo Tutup browser DramaFlow License Manager, lalu jalankan file ini jika sesi login bermasalah.
 echo File ini tidak menghapus data lisensi.
 pause
