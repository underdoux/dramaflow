DRAMAFLOW LICENSE MANAGER PORTABLE — WINDOWS 11

Jalankan:
1. Ekstrak folder ZIP ke lokasi yang aman, misalnya Documents\DramaFlow-License-Manager.
2. Klik dua kali START-WINDOWS.bat.
3. Saat pertama kali, buat password admin minimal 14 karakter.
4. Dashboard terbuka di http://127.0.0.1:8787.
5. Data disimpan di folder data\licenses.json. Backup folder data secara berkala.

Agar bisa diakses dari mana saja:
1. Buat akun Cloudflare dan tambahkan domain milikmu ke Cloudflare DNS.
2. Download cloudflared untuk Windows 64-bit dari situs resmi Cloudflare.
3. Jalankan `cloudflared tunnel login`.
4. Buat tunnel bernama dramaflow-license dan route hostname misalnya license.domainkamu.com ke http://localhost:8787.
5. Untuk quick tunnel pengujian, jalankan `cloudflared tunnel --url http://localhost:8787`. URL acak tidak tetap dan cocok hanya untuk tes.
6. Jangan expose port 8787 langsung ke internet. Gunakan Cloudflare Tunnel dan aktifkan Cloudflare Access untuk dashboard admin.
7. API website klien perlu dapat mencapai hostname publik HTTPS.

PENTING:
- PowerShell 5.1 sudah tersedia di Windows 11; tidak perlu install Python/PHP/Database.
- Cloudflared executable perlu diunduh terpisah dari sumber resmi Cloudflare.
- PC harus menyala dan internet aktif untuk menerima heartbeat.
- Jangan hapus/ubah file data\licenses.json. Backup rutin.
- Data saat ini berupa JSON lokal, bukan SQLite. Simpan di folder privat.
- Ini rilis beta awal. Uji pada staging sebelum dipakai untuk lisensi komersial.
- Dashboard admin memakai token sesi; lindungi hostname dashboard dengan Cloudflare Access.
- API activation endpoint publik agar website klien dapat menghubungi server; lisensi acak + domain allowlist menjadi validasi utamanya.

SETUP NAMED CLOUDFLARE TUNNEL (DOMAIN TETAP)
1. Tambahkan domain ke Cloudflare dan pastikan DNS dikelola Cloudflare.
2. Download cloudflared.exe resmi dan letakkan di folder yang sama dengan START-CLOUDFLARE-TUNNEL.bat.
3. Buka PowerShell: cloudflared.exe tunnel login
4. Buat tunnel: cloudflared.exe tunnel create dramaflow-license
5. Buat DNS: cloudflared.exe tunnel route dns dramaflow-license license.domainkamu.com
6. Salin UUID tunnel dan path credentials JSON ke config.yml.example, simpan sebagai config.yml di folder %USERPROFILE%\.cloudflared\config.yml (atau sesuaikan argumen run).
7. Jalankan START-WINDOWS.bat di satu jendela, lalu START-CLOUDFLARE-TUNNEL.bat di jendela lain.
8. URL server menjadi https://license.domainkamu.com.
Pastikan dashboard memakai password kuat. Untuk Cloudflare Access, buat aturan bypass khusus path /wp-json/dramaflow-license/v1/* agar website pelanggan dapat mengirim API tanpa login browser; lindungi path dashboard dengan Access. Jangan menerapkan Access login ke seluruh hostname karena API client tidak bisa menyelesaikan login interaktif.
