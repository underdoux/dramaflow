@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-License-Manager.ps1"
pause
