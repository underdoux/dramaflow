<?php get_header(); ?><main class="df-wrap df-page"><div class="df-section-head"><h1><?php post_type_archive_title(); ?></h1></div>
<form class="df-catalog-filter" method="get" action="<?php echo esc_url(get_post_type_archive_link('df_drama')); ?>">
<label>Genre <select name="df_genre"><option value="">Semua genre</option><?php foreach(get_terms(['taxonomy'=>'df_genre','hide_empty'=>false]) as $term): ?><option value="<?php echo esc_attr($term->slug); ?>" <?php selected(isset($_GET['df_genre'])?sanitize_title(wp_unslash($_GET['df_genre'])):'',$term->slug); ?>><?php echo esc_html($term->name); ?></option><?php endforeach; ?></select></label>
<label>Negara <select name="df_country"><option value="">Semua negara</option><?php foreach(get_terms(['taxonomy'=>'df_country','hide_empty'=>false]) as $term): ?><option value="<?php echo esc_attr($term->slug); ?>" <?php selected(isset($_GET['df_country'])?sanitize_title(wp_unslash($_GET['df_country'])):'',$term->slug); ?>><?php echo esc_html($term->name); ?></option><?php endforeach; ?></select></label>
<button type="submit">Filter</button><a href="<?php echo esc_url(get_post_type_archive_link('df_drama')); ?>">Reset</a></form>
<?php
$paged=max(1,get_query_var('paged'));
$args=['post_type'=>'df_drama','post_status'=>'publish','posts_per_page'=>20,'paged'=>$paged];
$tax=[];
foreach(['df_genre','df_country'] as $taxname){if(!empty($_GET[$taxname]))$tax[]=['taxonomy'=>$taxname,'field'=>'slug','terms'=>sanitize_title(wp_unslash($_GET[$taxname]))];}
if($tax)$args['tax_query']=$tax;
$q=new WP_Query($args);
?><div class="df-grid"><?php if($q->have_posts()):while($q->have_posts()):$q->the_post(); ?><a class="df-card" href="<?php the_permalink(); ?>"><div class="df-poster"><?php the_post_thumbnail('medium_large'); ?></div><h3><?php the_title(); ?></h3><div class="df-meta"><?php echo esc_html(get_post_meta(get_the_ID(),'_df_year',true)); ?></div></a><?php endwhile; else: ?><p class="df-empty">Belum ada drama yang sesuai filter.</p><?php endif; ?></div><?php echo wp_kses_post(paginate_links(['total'=>$q->max_num_pages,'current'=>$paged])); wp_reset_postdata(); ?></main><?php get_footer(); ?>