<?php get_header(); ?><main class="df-wrap df-page"><?php while(have_posts()):the_post();
$src=get_post_meta(get_the_ID(),'_df_video_url',true);
$drama_id=(int)get_post_meta(get_the_ID(),'_df_drama_id',true);
$number=(int)get_post_meta(get_the_ID(),'_df_episode_number',true);
$qualities=[];
foreach([360,480,720,1080] as $q){$u=get_post_meta(get_the_ID(),'_df_video_'.$q,true);if($u)$qualities[]=['label'=>$q.'p','url'=>$u];}
$sub=get_post_meta(get_the_ID(),'_df_subtitle_url',true);
$lang=get_post_meta(get_the_ID(),'_df_subtitle_lang',true)?:'id';
$label=get_post_meta(get_the_ID(),'_df_subtitle_label',true)?:'Indonesia';
$episodes=get_posts(['post_type'=>'df_episode','posts_per_page'=>-1,'meta_key'=>'_df_episode_number','orderby'=>'meta_value_num','order'=>'ASC','meta_query'=>[['key'=>'_df_drama_id','value'=>$drama_id,'compare'=>'=']]]);
$prev=$next=null;
foreach($episodes as $i=>$ep){if($ep->ID===get_the_ID()){$prev=$episodes[$i-1]??null;$next=$episodes[$i+1]??null;break;}}
?><p class="df-muted"><a href="<?php echo esc_url(get_permalink($drama_id)); ?>">← Kembali ke drama</a></p><h1><?php the_title(); ?></h1>
<div class="df-player">
<?php if($src): ?>
<video controls playsinline preload="metadata" src="<?php echo esc_url($src); ?>" data-default-source="<?php echo esc_url($src); ?>" data-sources="<?php echo esc_attr(wp_json_encode($qualities)); ?>">
<?php if($sub): ?><track kind="subtitles" src="<?php echo esc_url($sub); ?>" srclang="<?php echo esc_attr($lang); ?>" label="<?php echo esc_attr($label); ?>" default><?php endif; ?>
</video>
<?php else: ?><div class="df-empty">URL video belum diatur oleh admin.</div><?php endif; ?>
<?php if(function_exists('dramaflow_render_player_ad')) dramaflow_render_player_ad(get_the_ID()); ?>
</div>
<?php if($qualities): ?><p class="df-player-options"><label for="df-quality">Kualitas video: </label><select id="df-quality" class="df-quality-select"><option value="<?php echo esc_url($src); ?>">Auto / Default</option><?php foreach($qualities as $q): ?><option value="<?php echo esc_url($q['url']); ?>"><?php echo esc_html($q['label']); ?></option><?php endforeach; ?></select></p><?php endif; ?>
<nav class="df-episode-nav" aria-label="Navigasi episode"><?php if($prev): ?><a class="df-episode" href="<?php echo esc_url(get_permalink($prev)); ?>">← Episode sebelumnya</a><?php endif; ?><?php if($next): ?><a class="df-episode" href="<?php echo esc_url(get_permalink($next)); ?>">Episode berikutnya →</a><?php endif; ?></nav>
<?php the_content(); endwhile; ?></main><?php get_footer(); ?>