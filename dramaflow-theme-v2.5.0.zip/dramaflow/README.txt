DramaFlow Theme 1.1.0
Requires DramaFlow Core plugin for Drama and Episode content types and player affiliate overlays.

Version 2.2.0: Offline signed serial activation; see CHANGELOG.md.

Version 2.3.0: Online activation support. See docs/INSTALLATION-GUIDE.md and docs/LICENSE-SYSTEM-GUIDE.md in full source package.

Version 2.4.0: automatic 12-hour online heartbeat. See bundled documentation and CHANGELOG.md.
