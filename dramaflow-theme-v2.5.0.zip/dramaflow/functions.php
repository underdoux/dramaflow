<?php
if (!defined('ABSPATH')) exit;
define('DRAMAFLOW_THEME_VERSION','2.5.0');
add_action('after_setup_theme',function(){
 load_theme_textdomain('dramaflow',get_template_directory().'/languages');
 add_theme_support('title-tag'); add_theme_support('post-thumbnails');
 add_theme_support('custom-logo'); add_theme_support('html5',['search-form','comment-form','comment-list','gallery','caption','style','script']);
 register_nav_menus(['primary'=>__('Primary Menu','dramaflow')]);
});
add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('dramaflow-style',get_stylesheet_uri(),[],DRAMAFLOW_THEME_VERSION);
});
function dramaflow_core_active(){return post_type_exists('df_drama');}
function dramaflow_poster($id=null){$id=$id?:get_the_ID(); return get_the_post_thumbnail_url($id,'large') ?: '';}


function dft_license_domain() {
    $host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
    return preg_replace('/^www\./', '', $host);
}
function dft_verify_offline_license($key, $product) {
    $key = trim((string)$key);
    $parts = explode('.', $key);
    if (count($parts) !== 3 || $parts[0] !== 'DFL1') return new WP_Error('df_license_format','Format serial tidak valid.');
    $decode = function($v) { $v=strtr($v,'-_','+/'); return base64_decode($v.str_repeat('=',(4-strlen($v)%4)%4),true); };
    $payload_raw=$decode($parts[1]); $signature=$decode($parts[2]);
    if ($payload_raw===false || $signature===false) return new WP_Error('df_license_encoding','Serial tidak dapat dibaca.');
    $payload=json_decode($payload_raw,true);
    if (!is_array($payload) || empty($payload['product']) || empty($payload['domain'])) return new WP_Error('df_license_payload','Data lisensi tidak lengkap.');
    if (!hash_equals((string)$product,(string)$payload['product'])) return new WP_Error('df_license_product','Serial ini bukan untuk '.$product.'.');
    if (!hash_equals(dft_license_domain(),strtolower((string)$payload['domain']))) return new WP_Error('dft_license_domain','Serial hanya berlaku untuk domain '.$payload['domain'].'.');
    if (!empty($payload['expires']) && strtotime($payload['expires'].' 23:59:59') < time()) return new WP_Error('df_license_expired','Serial sudah kedaluwarsa.');
    $public_key = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzttII0pPd7xU9hs9kJUp\nYs0gaDdREBUU8XGa03NWzScCuVsNPjKyYRKdSF9973uZbCoqom6B8l6ZjFOYoLgO\nOjoeWgnA0csQAaedaRnAC8glwQE66FviSo//Oh5f9CVqps9oBWo4KOdjCQVOR/cF\nHgRdgGVfDwgwBX1zun/m9jQdPpK0hlHRTaR7FW2Fuxteqsc3jRa+CKiQFeaIffxO\n9jQc+Rd66W0OPIicxCmLJPvXkYMTJuV6ANhRSyNmCpUM32VdujshLcjA4us8NDLG\nD7MvF+DQA5F1kzUd5hSuzxw1u+AM1glWkIyEH5BOoHCnLLNS2TT5FS6BhoqjprTj\nYwIDAQAB\n-----END PUBLIC KEY-----\n";
    $ok=openssl_verify($payload_raw,$signature,$public_key,OPENSSL_ALGO_SHA256);
    if ($ok !== 1) return new WP_Error('df_license_signature','Tanda tangan serial tidak valid.');
    return $payload;
}

function dft_verify_license($key, $product) {
    if (get_option('dft_license_mode', 'offline') !== 'online') return dft_verify_offline_license($key, $product);
    $server = untrailingslashit(esc_url_raw(get_option('dft_license_server', '')));
    if (!$server || !wp_http_validate_url($server)) return new WP_Error('dft_license_server', 'URL License Server belum benar.');
    $response = wp_remote_post($server . '/wp-json/dramaflow-license/v1/activate', [
        'timeout' => 20,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode(['license_key' => $key, 'product' => $product, 'domain' => dft_license_domain(), 'version' => DRAMAFLOW_THEME_VERSION]),
    ]);
    if (is_wp_error($response)) return $response;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (wp_remote_retrieve_response_code($response) !== 200 || empty($body['success'])) {
        return new WP_Error('dft_license_online', $body['message'] ?? $body['code'] ?? 'Aktivasi online gagal.');
    }
    return $body;
}
add_filter('cron_schedules', function ($schedules) {
    if (!isset($schedules['dft_twelve_hours'])) $schedules['dft_twelve_hours'] = ['interval' => 43200, 'display' => 'Every 12 hours'];
    return $schedules;
});
add_action('init', function () {
    if (get_option('dft_license_mode', 'offline') === 'online' && get_option('df_theme_license_status') === 'active' && !wp_next_scheduled('dft_license_heartbeat')) {
        wp_schedule_event(time() + 300, 'dft_twelve_hours', 'dft_license_heartbeat');
    }
});
add_action('dft_license_heartbeat', function () {
    $key = get_option('df_theme_license_key', '');
    $server = untrailingslashit(esc_url_raw(get_option('dft_license_server', '')));
    if (!$key || !$server) return;
    $response = wp_remote_post($server . '/wp-json/dramaflow-license/v1/heartbeat', [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode(['license_key' => $key, 'product' => 'theme', 'domain' => dft_license_domain(), 'version' => DRAMAFLOW_THEME_VERSION]),
    ]);
    if (is_wp_error($response)) return;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    update_option('dft_license_last_check', current_time('mysql'));
    update_option('dft_license_last_response', !empty($body['success']) ? 'active' : 'invalid');
});

function df_theme_license_page() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['df_theme_license_key'])) {
        check_admin_referer('df_theme_license_action');
        if (isset($_POST['dft_license_mode'])) update_option('dft_license_mode',sanitize_key(wp_unslash($_POST['dft_license_mode']))==='online'?'online':'offline');
        if (isset($_POST['dft_license_server'])) update_option('dft_license_server',esc_url_raw(wp_unslash($_POST['dft_license_server'])));
        $key=sanitize_text_field(wp_unslash($_POST['df_theme_license_key']));
        $result=dft_verify_license($key,'theme');
        if (is_wp_error($result)) {
            update_option('df_theme_license_status','invalid');
            update_option('df_theme_license_error',$result->get_error_message());
        } else {
            update_option('df_theme_license_key',$key);
            update_option('df_theme_license_payload',$result);
            update_option('df_theme_license_status','active');
            delete_option('df_theme_license_error');
        }
    }
    $status=get_option('df_theme_license_status','inactive');
    echo '<div class="wrap"><h1>DramaFlow Theme License</h1><p>Status: <strong>'.esc_html($status).'</strong></p>';
    if(get_option('df_theme_license_error')) echo '<div class="notice notice-error"><p>'.esc_html(get_option('df_theme_license_error')).'</p></div>';
    echo '<form method="post">'; wp_nonce_field('df_theme_license_action');
    echo '<p><label>Mode aktivasi</label><br><select name="dft_license_mode"><option value="offline" '.selected(get_option('dft_license_mode','offline'),'offline',false).'>Offline</option><option value="online" '.selected(get_option('dft_license_mode','offline'),'online',false).'>Online</option></select></p><p><label>URL License Server</label><input class="regular-text" name="dft_license_server" value="'.esc_attr(get_option('dft_license_server','')).'" placeholder="https://license.domainkamu.com"></p>';
    echo '<textarea name="df_theme_license_key" class="large-text" rows="4" placeholder="Tempel serial number DramaFlow Theme">'.esc_textarea(get_option('df_theme_license_key','')).'</textarea><p>Domain perangkat ini: <code>'.esc_html(dft_license_domain()).'</code></p><button class="button button-primary">Aktifkan Theme</button></form></div>';
}
add_action('admin_menu',function(){add_theme_page('DramaFlow License','DramaFlow License','manage_options','df-theme-license','df_theme_license_page');});
add_action('admin_notices',function(){
    if(!current_user_can('manage_options') || get_option('df_theme_license_status')==='active') return;
    echo '<div class="notice notice-warning"><p>DramaFlow Theme belum diaktivasi. Buka Appearance → DramaFlow License untuk memasukkan serial.</p></div>';
});
