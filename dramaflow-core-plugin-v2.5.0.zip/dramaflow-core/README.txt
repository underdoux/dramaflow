DramaFlow Core 2.2.0
Includes offline signed license activation. See CHANGELOG.md for full version history.

Version 2.3.0: Online activation support. See docs/INSTALLATION-GUIDE.md and docs/LICENSE-SYSTEM-GUIDE.md in full source package.

Version 2.4.0: automatic 12-hour online heartbeat. See bundled documentation and CHANGELOG.md.
