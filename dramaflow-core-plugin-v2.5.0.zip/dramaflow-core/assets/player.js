(function () {
  'use strict';
  function initPlayer() {
    var video = document.querySelector('.df-player video');
    if (!video) return;
    var sources = [];
    try { sources = JSON.parse(video.dataset.sources || '[]'); } catch (e) {}
    var hlsInstance = null;
    function attach(url) {
      if (!url) return;
      if (hlsInstance) { hlsInstance.destroy(); hlsInstance = null; }
      var isHls = /\.m3u8(?:$|\?)/i.test(url);
      if (isHls && window.Hls && window.Hls.isSupported()) {
        hlsInstance = new Hls({ enableWorker: true });
        hlsInstance.loadSource(url);
        hlsInstance.attachMedia(video);
      } else {
        video.src = url;
        video.load();
      }
    }
    var defaultSource = video.dataset.defaultSource || video.getAttribute('src');
    attach(defaultSource);
    var quality = document.querySelector('.df-quality-select');
    if (quality) {
      quality.addEventListener('change', function () {
        var selected = quality.value;
        if (selected) {
          var wasPlaying = !video.paused;
          var current = video.currentTime;
          attach(selected);
          video.addEventListener('loadedmetadata', function restore() {
            video.currentTime = current;
            if (wasPlaying) video.play().catch(function(){});
            video.removeEventListener('loadedmetadata', restore);
          });
        }
      });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initPlayer);
  else initPlayer();
})();