# DramaFlow — Panduan Instalasi & Operasional

## Isi paket
- `dramaflow-theme-v2.3.0.zip`: theme tampilan OTT.
- `dramaflow-core-plugin-v2.3.0.zip`: CPT drama/episode, player, affiliate, SEO, demo import, lisensi.
- `dramaflow-license-server-v1.0.0.zip`: server lisensi online terpisah.
- `dramaflow-offline-serial-generator-v1.0.0.zip`: generator serial offline.
- `sample-drama-import.json`: contoh format import konten.
- `CHANGELOG.md`: riwayat perubahan versi.

## Persyaratan
- WordPress 6.0+; PHP 8.0+ direkomendasikan.
- HTTPS untuk situs produksi, terutama bila memakai online licensing.
- PHP OpenSSL aktif untuk verifikasi lisensi offline dan generator.
- Backup database dan file sebelum update.

## Instalasi situs DramaFlow
1. Masuk WordPress Admin → Appearance → Themes → Add New → Upload Theme.
2. Upload `dramaflow-theme-v2.3.0.zip`, install, lalu Activate.
3. Plugins → Add New → Upload Plugin.
4. Upload `dramaflow-core-plugin-v2.3.0.zip`, install, lalu Activate.
5. Buka Settings → Permalinks dan klik Save Changes untuk refresh rewrite rules.
6. Buka DramaFlow → Demo & Import lalu klik Pasang Dummy Data untuk membuat katalog contoh. Dummy data berisi konten fiktif, bukan poster/video berlisensi.
7. Buat drama, episode, genre, negara, thumbnail, dan sumber video milik sendiri. Pastikan memiliki hak distribusi atas video dan poster.
8. Atur menu navigasi melalui Appearance → Menus (atau editor navigasi sesuai versi WordPress).

## Mengisi konten
- Drama: DramaFlow → Dramas. Isi judul, sinopsis, featured image, tahun, negara, genre, SEO title/description.
- Episode: DramaFlow → Episodes. Pilih parent drama, nomor episode, URL video, pilihan kualitas, subtitle WebVTT.
- Player Ads: DramaFlow → Player Ads. Isi gambar iklan, URL affiliate, cakupan episode, jadwal, dan status aktif.
- JSON import: DramaFlow → Demo & Import. Upload JSON; hasil impor menjadi draft untuk diperiksa. Gunakan sample-drama-import.json sebagai pola.
- Video: gunakan URL MP4 atau HLS manifest `.m3u8` yang sah. HLS.js memakai CDN; ketersediaan tergantung jaringan/browser.
- Subtitle: gunakan file WebVTT `.vtt` dengan URL yang dapat diakses browser.

## Affiliate
1. Buat campaign Player Ads.
2. Isi gambar kreatif dan URL affiliate.
3. Pilih semua episode atau episode tertentu.
4. Atur jadwal tayang dan aktifkan campaign.
5. Laporan tersedia di DramaFlow → Affiliate Reports.
6. Angka impression dihitung saat markup iklan dirender; klik adalah klik redirect yang tercatat. Ini bukan data transaksi, penjualan, atau komisi marketplace.
7. Cantumkan disclosure affiliate sesuai ketentuan platform dan hukum yang berlaku.

## Integrasi analitik dan SEO
- DramaFlow → Integrations: masukkan GA4 Measurement ID dan Search Console verification meta.
- Search Console OAuth memerlukan Google Cloud project, Search Console API aktif, OAuth Web Client, redirect URI persis seperti yang ditampilkan di halaman Integrations.
- SEO Assistant membuat draft lokal; admin tetap harus meninjau dan menerapkan.
- Search Console opportunity analyzer menggunakan heuristik, bukan jaminan ranking atau riset volume keyword.

## Update
1. Backup database dan file.
2. Upload versi theme/plugin baru melalui WordPress. Jika WordPress menolak overwrite, hapus versi lama setelah backup lalu upload ZIP baru.
3. Jangan menghapus plugin sebelum mencadangkan data; konten drama/episode tersimpan di database.
4. Periksa CHANGELOG sebelum update, lalu cek Permalinks dan halaman utama.
5. Theme dan plugin dikembangkan terpisah; gunakan pasangan versi yang sama.

## Troubleshooting
- Katalog kosong: pastikan Core Plugin aktif, lalu pasang dummy data atau buat drama.
- 404 drama/episode: Settings → Permalinks → Save Changes.
- Player kosong: periksa URL video, CORS, MIME type, HTTPS, dan hak akses sumber.
- Subtitle tidak muncul: pastikan WebVTT valid dan dapat diakses lintas origin.
- Lisensi gagal: cek mode, product serial, domain, tanggal kedaluwarsa, OpenSSL, URL server, serta HTTPS.
- Search Console gagal: cek OAuth redirect URI, API enabled, token, dan properti yang sudah diverifikasi.

## Catatan batasan
Paket ini belum melalui pengujian end-to-end pada hosting pengguna. Uji di staging sebelum produksi. Tidak termasuk hosting video/CDN, konten film, poster berlisensi, payment gateway, ataupun dashboard komisi marketplace.
