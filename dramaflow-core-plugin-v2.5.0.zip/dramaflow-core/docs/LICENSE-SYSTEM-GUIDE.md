# DramaFlow License System — Dokumentasi

## Arsitektur
Theme dan Core Plugin mempunyai lisensi terpisah. Mode aktivasi dipilih di halaman lisensi masing-masing:
- Offline: serial bertanda tangan RSA-SHA256 diverifikasi lokal memakai public key yang tertanam.
- Online: WordPress mengirim serial, produk, dan domain ke REST API License Server. Server memeriksa status, tanggal kedaluwarsa, dan daftar domain yang diizinkan.

## Online License Server — instalasi
1. Siapkan WordPress terpisah khusus manajemen lisensi, idealnya subdomain seperti `license.example.com`, HTTPS aktif.
2. Plugins → Add New → Upload Plugin → pilih `dramaflow-license-server-v1.0.0.zip`.
3. Aktifkan plugin. Tabel lisensi dan aktivasi dibuat otomatis.
4. Buka menu DramaFlow Licenses.
5. Buat serial untuk produk Theme atau Core. Masukkan domain yang diperbolehkan, satu domain per baris. Opsional masukkan tanggal kedaluwarsa.
6. Salin serial yang ditampilkan saat dibuat. Server hanya menyimpan SHA-256 hash, sehingga serial penuh tidak dapat dipulihkan dari daftar.
7. Distribusikan serial kepada pemilik situs yang diizinkan.

## Aktivasi online di website klien
1. Install dan aktifkan DramaFlow Theme dan Core Plugin.
2. Theme: Appearance → DramaFlow License. Plugin: DramaFlow → Core License.
3. Pilih Online.
4. Masukkan URL root server lisensi, contoh `https://license.example.com` (tanpa `/wp-json`).
5. Tempel serial yang sesuai produk.
6. Klik Aktifkan. Server akan menolak domain yang tidak terdaftar.
7. Theme dan Core membutuhkan serial masing-masing.

## Monitoring
Menu DramaFlow Licenses menampilkan serial hint, produk, domain yang diizinkan, jumlah domain aktif, expiry, status lisensi, dan daftar aktivasi domain beserta waktu aktivasi/pengecekan terakhir.
Admin dapat mengaktifkan/menonaktifkan lisensi. Lisensi disabled akan ditolak pada pengecekan aktivasi berikutnya.

## Offline generator — instalasi dan penggunaan
1. Ekstrak ZIP `dramaflow-offline-serial-generator-v1.0.0.zip` di komputer privat.
2. Pastikan PHP 8+ dan ekstensi OpenSSL.
3. Ubah password awal di `generator.php` sebelum digunakan.
4. Jalankan dari folder tersebut: `php -S 127.0.0.1:8088`.
5. Buka `http://127.0.0.1:8088/generator.php`.
6. Pilih produk, masukkan domain, tanggal expiry opsional, lalu generate.
7. Masukkan serial ke halaman lisensi dengan mode Offline.

## Keamanan wajib
- Jangan mengunggah `private.pem` atau folder generator ke website publik.
- Simpan private key dalam backup terenkripsi dan akses terbatas. Kehilangan private key berarti serial offline baru tidak bisa ditandatangani dengan pasangan public key lama.
- Server online harus menggunakan HTTPS, backup rutin, password admin kuat, 2FA bila tersedia, dan pembatasan akses admin.
- Serial online dibuat dengan random string; database menyimpan hash serial, bukan plaintext.
- Jangan membagikan serial antar pelanggan.

## Perbedaan & keterbatasan
- Offline tidak memerlukan server, tetapi tidak bisa dicabut atau dimonitor jarak jauh.
- Online memungkinkan kontrol status dan daftar domain dari server.
- Online activation endpoint mencatat aktivasi domain. Klien melakukan request saat aktivasi; pemeriksaan ulang otomatis terjadwal dan penguncian fitur penuh belum menjadi bagian implementasi awal ini.
- Nonaktifkan lisensi di server agar aktivasi baru dan pengecekan berikutnya ditolak. Situs yang sudah aktif mungkin tetap berjalan sampai dilakukan validasi ulang; jangan menganggap pencabutan instan.
- Satu serial terikat pada satu produk; Theme dan Core memerlukan serial terpisah.
- Perpindahan domain: tambahkan domain baru ke daftar yang diizinkan dan lakukan aktivasi ulang. Hapus/nonaktifkan record lama melalui pengelolaan database bila perlu; UI manajemen aktivasi individual belum disediakan.

## REST API
Base: `/wp-json/dramaflow-license/v1/`
- `POST /activate`: `license_key`, `product` (`theme` atau `core`), `domain`.
- `POST /check`: pemeriksaan status aktivasi.
- `POST /deactivate`: menonaktifkan record domain untuk lisensi.
Endpoint bersifat publik tetapi memerlukan serial valid. Gunakan HTTPS. Jangan mengirim serial melalui URL/query string.

## Portable License Manager for Windows 11
The optional portable manager is distributed separately as `dramaflow-license-manager-portable-v1.0.0.zip`. Extract it, run `START-WINDOWS.bat`, and create an admin password on first launch. It uses Windows PowerShell and JSON storage; Python, PHP and a database server are not required. For remote access, configure a named Cloudflare Tunnel and DNS hostname using `config.yml.example` and `START-CLOUDFLARE-TUNNEL.bat`. Keep the PC powered on. Websites activated online send a heartbeat every 12 hours; the dashboard marks a site offline after 36 hours without a heartbeat. Dashboard password protection is built in; protect dashboard paths with Cloudflare Access while allowing the WordPress API paths to pass through.
