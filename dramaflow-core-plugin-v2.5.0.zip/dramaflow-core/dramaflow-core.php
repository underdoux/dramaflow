<?php
/**
 * Plugin Name: DramaFlow Core
 * Description: Streaming content, player affiliate image campaigns, click analytics and SEO assistant foundation.
 * Version: 2.5.0
 * Author: DramaFlow
 * Requires PHP: 8.0
 */
if (!defined('ABSPATH')) exit;
define('DF_CORE_VER','2.5.0');

function df_license_domain() {
    $host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
    return preg_replace('/^www\./', '', $host);
}
function df_verify_offline_license($key, $product) {
    $key = trim((string)$key);
    $parts = explode('.', $key);
    if (count($parts) !== 3 || $parts[0] !== 'DFL1') return new WP_Error('df_license_format','Format serial tidak valid.');
    $decode = function($v) { $v=strtr($v,'-_','+/'); return base64_decode($v.str_repeat('=',(4-strlen($v)%4)%4),true); };
    $payload_raw=$decode($parts[1]); $signature=$decode($parts[2]);
    if ($payload_raw===false || $signature===false) return new WP_Error('df_license_encoding','Serial tidak dapat dibaca.');
    $payload=json_decode($payload_raw,true);
    if (!is_array($payload) || empty($payload['product']) || empty($payload['domain'])) return new WP_Error('df_license_payload','Data lisensi tidak lengkap.');
    if (!hash_equals((string)$product,(string)$payload['product'])) return new WP_Error('df_license_product','Serial ini bukan untuk '.$product.'.');
    if (!hash_equals(df_license_domain(),strtolower((string)$payload['domain']))) return new WP_Error('df_license_domain','Serial hanya berlaku untuk domain '.$payload['domain'].'.');
    if (!empty($payload['expires']) && strtotime($payload['expires'].' 23:59:59') < time()) return new WP_Error('df_license_expired','Serial sudah kedaluwarsa.');
    $public_key = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzttII0pPd7xU9hs9kJUp\nYs0gaDdREBUU8XGa03NWzScCuVsNPjKyYRKdSF9973uZbCoqom6B8l6ZjFOYoLgO\nOjoeWgnA0csQAaedaRnAC8glwQE66FviSo//Oh5f9CVqps9oBWo4KOdjCQVOR/cF\nHgRdgGVfDwgwBX1zun/m9jQdPpK0hlHRTaR7FW2Fuxteqsc3jRa+CKiQFeaIffxO\n9jQc+Rd66W0OPIicxCmLJPvXkYMTJuV6ANhRSyNmCpUM32VdujshLcjA4us8NDLG\nD7MvF+DQA5F1kzUd5hSuzxw1u+AM1glWkIyEH5BOoHCnLLNS2TT5FS6BhoqjprTj\nYwIDAQAB\n-----END PUBLIC KEY-----\n";
    $ok=openssl_verify($payload_raw,$signature,$public_key,OPENSSL_ALGO_SHA256);
    if ($ok !== 1) return new WP_Error('df_license_signature','Tanda tangan serial tidak valid.');
    return $payload;
}


function df_verify_license($key,$product) {
    if (get_option('df_license_mode','offline') !== 'online') return df_verify_offline_license($key,$product);
    $server=untrailingslashit(esc_url_raw(get_option('df_license_server','')));
    if (!$server || !wp_http_validate_url($server)) return new WP_Error('license_server','URL License Server belum benar.');
    $res=wp_remote_post($server.'/wp-json/dramaflow-license/v1/activate',['timeout'=>20,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['license_key'=>$key,'product'=>$product,'domain'=>df_license_domain()])]);
    if (is_wp_error($res)) return $res;
    $body=json_decode(wp_remote_retrieve_body($res),true);
    if (wp_remote_retrieve_response_code($res)!==200 || empty($body['success'])) return new WP_Error('license_online',$body['message']??($body['code']??'Aktivasi online gagal.'));
    return $body;
}


add_filter('cron_schedules',function($s){if(!isset($s['df_twelve_hours']))$s['df_twelve_hours']=['interval'=>43200,'display'=>'Every 12 hours'];return $s;});
add_action('init',function(){if(get_option('df_license_mode','offline')==='online' && get_option('df_core_license_status')==='active' && !wp_next_scheduled('df_license_heartbeat'))wp_schedule_event(time()+300,'df_twelve_hours','df_license_heartbeat');});
add_action('df_license_heartbeat',function(){
 $key=get_option('df_core_license_key','');$server=untrailingslashit(esc_url_raw(get_option('df_license_server','')));
 if(!$key||!$server)return;
 $res=wp_remote_post($server.'/wp-json/dramaflow-license/v1/heartbeat',['timeout'=>15,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['license_key'=>$key,'product'=>'core','domain'=>df_license_domain(),'version'=>defined('DF_CORE_VER')?DF_CORE_VER:'unknown'])]);
 if(is_wp_error($res))return;
 $data=json_decode(wp_remote_retrieve_body($res),true);
 update_option('df_license_last_check',current_time('mysql'));
 update_option('df_license_last_response',(!empty($data['success'])?'active':'invalid'));
});

function df_core_license_page() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['df_core_license_key'])) {
        check_admin_referer('df_core_license_action');
        if (isset($_POST['df_license_mode'])) update_option('df_license_mode',sanitize_key(wp_unslash($_POST['df_license_mode']))==='online'?'online':'offline');
        if (isset($_POST['df_license_server'])) update_option('df_license_server',esc_url_raw(wp_unslash($_POST['df_license_server'])));
        $key=sanitize_text_field(wp_unslash($_POST['df_core_license_key']));
        $result=df_verify_license($key,'core');
        if (is_wp_error($result)) {
            update_option('df_core_license_status','invalid');
            update_option('df_core_license_error',$result->get_error_message());
        } else {
            update_option('df_core_license_key',$key);
            update_option('df_core_license_payload',$result);
            update_option('df_core_license_status','active');
            delete_option('df_core_license_error');
        }
    }
    echo '<div class="wrap"><h1>DramaFlow Core License</h1><p>Status: <strong>'.esc_html(get_option('df_core_license_status','inactive')).'</strong></p>';
    if(get_option('df_core_license_error')) echo '<div class="notice notice-error"><p>'.esc_html(get_option('df_core_license_error')).'</p></div>';
    echo '<form method="post">'; wp_nonce_field('df_core_license_action');
    echo '<p><label>Mode aktivasi</label><br><select name="df_license_mode"><option value="offline" '.selected(get_option('df_license_mode','offline'),'offline',false).'>Offline</option><option value="online" '.selected(get_option('df_license_mode','offline'),'online',false).'>Online</option></select></p>';
    echo '<p><label>URL License Server</label><input class="regular-text" name="df_license_server" value="'.esc_attr(get_option('df_license_server','')).'" placeholder="https://license.domainkamu.com"></p>';

    echo '<textarea name="df_core_license_key" class="large-text" rows="4" placeholder="Tempel serial number DramaFlow Core">'.esc_textarea(get_option('df_core_license_key','')).'</textarea><p>Domain perangkat ini: <code>'.esc_html(df_license_domain()).'</code></p><button class="button button-primary">Aktifkan Core Plugin</button></form></div>';
}
add_action('admin_menu',function(){add_submenu_page('dramaflow','Core License','Core License','manage_options','df-core-license','df_core_license_page');});
add_action('admin_notices',function(){
    if(!current_user_can('manage_options') || get_option('df_core_license_status')==='active') return;
    echo '<div class="notice notice-warning"><p>DramaFlow Core belum diaktivasi. Buka DramaFlow → Core License untuk memasukkan serial.</p></div>';
});


register_activation_hook(__FILE__, 'df_activate');
function df_activate() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = $wpdb->prefix . 'df_affiliate_clicks';
    $charset = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE $table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        ad_id bigint(20) unsigned NOT NULL,
        clicked_at datetime NOT NULL,
        referer text NULL,
        ip_hash char(64) NULL,
        event_type varchar(20) NOT NULL DEFAULT 'click',
        PRIMARY KEY  (id),
        KEY ad_id (ad_id),
        KEY clicked_at (clicked_at)
    ) $charset;");
    df_register_content();
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, function(){ flush_rewrite_rules(); });

function df_maybe_upgrade_schema() {
    if (get_option('df_db_schema_version') === '2.0.0') return;
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = $wpdb->prefix . 'df_affiliate_clicks';
    $charset = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE $table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        ad_id bigint(20) unsigned NOT NULL,
        clicked_at datetime NOT NULL,
        referer text NULL,
        ip_hash char(64) NULL,
        event_type varchar(20) NOT NULL DEFAULT 'click',
        PRIMARY KEY  (id),
        KEY ad_id (ad_id),
        KEY clicked_at (clicked_at)
    ) $charset;");
    update_option('df_db_schema_version','2.0.0');
}
add_action('admin_init','df_maybe_upgrade_schema');

add_action('init', 'df_register_content');
function df_register_content() {
    register_post_type('df_drama', [
        'labels'=>['name'=>'Dramas','singular_name'=>'Drama','add_new_item'=>'Add New Drama'],
        'public'=>true,'has_archive'=>true,'menu_icon'=>'dashicons-format-video',
        'supports'=>['title','editor','thumbnail','excerpt'],'rewrite'=>['slug'=>'drama'],
    ]);
    register_post_type('df_episode', [
        'labels'=>['name'=>'Episodes','singular_name'=>'Episode','add_new_item'=>'Add New Episode'],
        'public'=>true,'has_archive'=>false,'menu_icon'=>'dashicons-playlist-video',
        'supports'=>['title','editor','thumbnail'],'rewrite'=>['slug'=>'episode'],
    ]);
    register_post_type('df_player_ad', [
        'labels'=>['name'=>'Player Ads','singular_name'=>'Player Ad','add_new_item'=>'Add New Ad Campaign'],
        'public'=>false,'show_ui'=>true,'show_in_menu'=>'dramaflow',
        'supports'=>['title'],'menu_icon'=>'dashicons-images-alt2',
    ]);
    register_taxonomy('df_genre','df_drama',['label'=>'Genres','public'=>true,'hierarchical'=>true,'rewrite'=>['slug'=>'genre']]);
    register_taxonomy('df_country','df_drama',['label'=>'Countries','public'=>true,'hierarchical'=>true,'rewrite'=>['slug'=>'country']]);
}

add_action('add_meta_boxes', function(){
    add_meta_box('df_drama_info','Drama Information','df_drama_box','df_drama','normal','high');
    add_meta_box('df_drama_seo','DramaFlow SEO','df_drama_seo_box','df_drama','normal','default');
    add_meta_box('df_episode_info','Episode & Video','df_episode_box','df_episode','normal','high');
    add_meta_box('df_ad_campaign','Player Affiliate Campaign','df_ad_campaign_box','df_player_ad','normal','high');
});
function df_nonce_field($post){ wp_nonce_field('df_save_meta','df_meta_nonce'); }
function df_drama_box($post) {
    df_nonce_field($post);
    foreach(['year'=>'Release Year','country'=>'Country / Region'] as $key=>$label) {
        echo '<p><label>'.esc_html($label).'</label><br><input class="widefat" name="df_'.$key.'" value="'.esc_attr(get_post_meta($post->ID,'_df_'.$key,true)).'"></p>';
    }
}

function df_drama_seo_box($post) {
    $title=get_post_meta($post->ID,'_df_seo_title',true);
    $desc=get_post_meta($post->ID,'_df_seo_description',true);
    echo '<p><label>SEO Title</label><input class="widefat" maxlength="65" name="df_seo_title" value="'.esc_attr($title).'" placeholder="'.esc_attr(get_the_title($post)).'"></p>';
    echo '<p><label>Meta Description</label><textarea class="widefat" rows="3" maxlength="180" name="df_seo_description" placeholder="Ringkasan singkat dan unik tentang drama ini">'.esc_textarea($desc).'</textarea></p>';
    echo '<p class="description">Kosongkan untuk menggunakan judul dan ringkasan bawaan. Perubahan SEO disimpan oleh admin.</p>';
}

function df_episode_box($post) {
    df_nonce_field($post);
    $drama=(int)get_post_meta($post->ID,'_df_drama_id',true);
    $num=get_post_meta($post->ID,'_df_episode_number',true);
    $url=get_post_meta($post->ID,'_df_video_url',true);
    echo '<p><label>Parent Drama</label><select class="widefat" name="df_drama_id"><option value="0">Select drama</option>';
    foreach(get_posts(['post_type'=>'df_drama','numberposts'=>-1]) as $d)
        echo '<option value="'.(int)$d->ID.'" '.selected($drama,$d->ID,false).'>'.esc_html($d->post_title).'</option>';
    echo '</select></p><p><label>Episode Number</label><input class="widefat" type="number" min="1" name="df_episode_number" value="'.esc_attr($num).'"></p>';
    echo '<p><label>Default Video URL (MP4 atau HLS .m3u8)</label><input class="widefat" type="url" name="df_video_url" value="'.esc_attr($url).'"></p>';
    foreach ([360,480,720,1080] as $quality) {
        $qv=get_post_meta($post->ID,'_df_video_'.$quality,true);
        echo '<p><label>Video '.$quality.'p URL (opsional)</label><input class="widefat" type="url" name="df_video_'.$quality.'" value="'.esc_attr($qv).'"></p>';
    }
    $sub=get_post_meta($post->ID,'_df_subtitle_url',true);
    $lang=get_post_meta($post->ID,'_df_subtitle_lang',true) ?: 'id';
    $label=get_post_meta($post->ID,'_df_subtitle_label',true) ?: 'Indonesia';
    echo '<p><label>Subtitle WebVTT URL (.vtt)</label><input class="widefat" type="url" name="df_subtitle_url" value="'.esc_attr($sub).'"></p>';
    echo '<p><label>Subtitle language code</label><input class="widefat" name="df_subtitle_lang" value="'.esc_attr($lang).'"></p>';
    echo '<p><label>Subtitle label</label><input class="widefat" name="df_subtitle_label" value="'.esc_attr($label).'"></p>';
    echo '<p class="description">Gunakan URL video dan subtitle yang kamu miliki atau berhak distribusikan. Subtitle menggunakan format WebVTT (.vtt).</p>';
}
function df_ad_campaign_box($post) {
    df_nonce_field($post);
    $img=get_post_meta($post->ID,'_df_ad_image',true);
    $url=get_post_meta($post->ID,'_df_ad_url',true);
    $scope=get_post_meta($post->ID,'_df_ad_scope',true) ?: 'all';
    $episodes=(array)get_post_meta($post->ID,'_df_ad_episodes',true);
    $start=get_post_meta($post->ID,'_df_ad_start',true);
    $end=get_post_meta($post->ID,'_df_ad_end',true);
    $enabled=get_post_meta($post->ID,'_df_ad_enabled',true);
    echo '<p><label><input type="checkbox" name="df_ad_enabled" value="1" '.checked($enabled,'1',false).'> Aktifkan kampanye</label></p>';
    echo '<p><label>Gambar iklan (URL Media Library)</label><input class="widefat" type="url" name="df_ad_image" value="'.esc_attr($img).'"></p>';
    echo '<p><label>Link affiliate tujuan</label><input class="widefat" type="url" name="df_ad_url" value="'.esc_attr($url).'"></p>';
    echo '<p><label>Penempatan</label><select name="df_ad_scope"><option value="all" '.selected($scope,'all',false).'>Semua player</option><option value="selected" '.selected($scope,'selected',false).'>Episode tertentu</option></select></p>';
    echo '<p><label>Episode target (pilih satu atau lebih)</label><select class="widefat" multiple size="6" name="df_ad_episodes[]">';
    foreach(get_posts(['post_type'=>'df_episode','numberposts'=>-1]) as $ep)
        echo '<option value="'.(int)$ep->ID.'" '.selected(in_array((int)$ep->ID,array_map('intval',$episodes),true),true,false).'>'.esc_html($ep->post_title).'</option>';
    echo '</select><span class="description">Gunakan Ctrl/Command untuk memilih beberapa episode. Diabaikan jika penempatan Semua player.</span></p>';
    echo '<div style="display:flex;gap:16px;flex-wrap:wrap"><p><label>Mulai tayang</label><br><input type="datetime-local" name="df_ad_start" value="'.esc_attr($start).'"></p><p><label>Akhir tayang</label><br><input type="datetime-local" name="df_ad_end" value="'.esc_attr($end).'"></p></div>';
    echo '<p class="description">Ukuran tampilan responsif: maksimal 280px desktop dan 38% lebar player di mobile. Iklan diberi label dan tombol tutup.</p>';
}
add_action('save_post', function($id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!isset($_POST['df_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['df_meta_nonce'])),'df_save_meta')) return;
    if (!current_user_can('edit_post',$id)) return;
    $type=get_post_type($id);
    $fields=['year'=>'text','country'=>'text','drama_id'=>'int','episode_number'=>'int','video_url'=>'url','video_360'=>'url','video_480'=>'url','video_720'=>'url','video_1080'=>'url','subtitle_url'=>'url','subtitle_lang'=>'text','subtitle_label'=>'text','seo_title'=>'text','seo_description'=>'textarea','ad_image'=>'url','ad_url'=>'url','ad_scope'=>'text','ad_start'=>'text','ad_end'=>'text'];
    foreach($fields as $key=>$kind) {
        $field='df_'.$key;
        if (!isset($_POST[$field])) continue;
        $raw=wp_unslash($_POST[$field]);
        if ($kind==='url') $value=esc_url_raw($raw);
        elseif ($kind==='int') $value=absint($raw);
        elseif ($kind==='textarea') $value=sanitize_textarea_field($raw); else $value=sanitize_text_field($raw);
        update_post_meta($id,'_df_'.$key,$value);
    }
    if ($type==='df_player_ad') {
        update_post_meta($id,'_df_ad_episodes',isset($_POST['df_ad_episodes'])?array_values(array_filter(array_map('absint',(array)wp_unslash($_POST['df_ad_episodes'])))) : []);
        if (isset($_POST['df_ad_enabled'])) update_post_meta($id,'_df_ad_enabled','1'); else update_post_meta($id,'_df_ad_enabled','0');
        $dest=get_post_meta($id,'_df_ad_url',true);
        if ($dest && !wp_http_validate_url($dest)) update_post_meta($id,'_df_ad_url','');
    }
});

function df_campaign_is_live($ad_id) {
    if (get_post_status($ad_id)!=='publish' || get_post_meta($ad_id,'_df_ad_enabled',true)!=='1') return false;
    $now=current_time('timestamp');
    $start=get_post_meta($ad_id,'_df_ad_start',true);
    $end=get_post_meta($ad_id,'_df_ad_end',true);
    if ($start && strtotime($start, current_time('timestamp')) > $now) return false;
    if ($end && strtotime($end, current_time('timestamp')) < $now) return false;
    return true;
}
function df_get_player_campaigns($episode_id) {
    $ads=get_posts(['post_type'=>'df_player_ad','post_status'=>'publish','numberposts'=>-1,'meta_query'=>[['key'=>'_df_ad_enabled','value'=>'1']]]);
    $eligible=[];
    foreach($ads as $ad) {
        if (!df_campaign_is_live($ad->ID)) continue;
        $scope=get_post_meta($ad->ID,'_df_ad_scope',true) ?: 'all';
        $targets=array_map('intval',(array)get_post_meta($ad->ID,'_df_ad_episodes',true));
        if ($scope==='all' || in_array((int)$episode_id,$targets,true)) {
            if (get_post_meta($ad->ID,'_df_ad_image',true) && get_post_meta($ad->ID,'_df_ad_url',true)) $eligible[]=$ad;
        }
    }
    return $eligible;
}
function df_track_url($ad_id) { return add_query_arg(['df_aff_click'=>absint($ad_id)],home_url('/')); }
add_action('template_redirect', function(){
    if (!isset($_GET['df_aff_click'])) return;
    $id=absint($_GET['df_aff_click']);
    if (!$id || get_post_type($id)!=='df_player_ad' || !df_campaign_is_live($id)) wp_die('Kampanye affiliate tidak tersedia.', 'DramaFlow', ['response'=>404]);
    $dest=get_post_meta($id,'_df_ad_url',true);
    $parts=wp_parse_url($dest);
    if (!$parts || empty($parts['scheme']) || !in_array(strtolower($parts['scheme']),['http','https'],true) || empty($parts['host'])) wp_die('Tujuan affiliate tidak valid.');
    global $wpdb; $table=$wpdb->prefix.'df_affiliate_clicks';
    $ip=isset($_SERVER['REMOTE_ADDR'])?sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])):'';
    $ref=isset($_SERVER['HTTP_REFERER'])?esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])):'';
    $wpdb->insert($table,['ad_id'=>$id,'clicked_at'=>current_time('mysql'),'referer'=>$ref,'ip_hash'=>$ip?hash_hmac('sha256',$ip,wp_salt('auth')):null,'event_type'=>'click'],['%d','%s','%s','%s','%s']);
    wp_redirect(esc_url_raw($dest),302,'DramaFlow Affiliate'); exit;
});
add_action('wp_enqueue_scripts', function() {
    if (!is_singular('df_episode')) return;
    wp_enqueue_script('dramaflow-hls','https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js',[], '1.5.17', true);
    wp_enqueue_script('dramaflow-player',plugin_dir_url(__FILE__).'assets/player.js',['dramaflow-hls'],'1.3.0',true);
});
function dramaflow_render_player_ad($episode_id) {
    $ads=df_get_player_campaigns($episode_id);
    if (!$ads) return;
    global $wpdb;
    $table=$wpdb->prefix.'df_affiliate_clicks';
    // Prefer campaigns with the fewest recorded impressions to distribute exposure.
    $counts=[];
    foreach($ads as $candidate) {
        $counts[$candidate->ID]=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE ad_id=%d AND event_type='impression'",
            $candidate->ID
        ));
    }
    $min=min($counts);
    $least=array_filter($ads,function($candidate) use($counts,$min){return $counts[$candidate->ID]===$min;});
    $least=array_values($least);
    $ad=$least[array_rand($least)];
    $wpdb->insert($table,[
        'ad_id'=>$ad->ID,'clicked_at'=>current_time('mysql'),
        'referer'=>isset($_SERVER['REQUEST_URI'])?esc_url_raw(home_url(wp_unslash($_SERVER['REQUEST_URI']))):'',
        'ip_hash'=>null,'event_type'=>'impression'
    ],['%d','%s','%s','%s','%s']);
    $img=get_post_meta($ad->ID,'_df_ad_image',true);
    echo '<div class="df-ad-overlay"><span class="df-ad-label">Iklan</span><button class="df-ad-close" type="button" aria-label="Tutup iklan">×</button><a href="'.esc_url(df_track_url($ad->ID)).'" target="_blank" rel="sponsored nofollow noopener"><img src="'.esc_url($img).'" alt="'.esc_attr(get_the_title($ad)).'"></a></div>';
}
add_action('wp_footer', function(){ ?>
<script>document.addEventListener('click',function(e){if(e.target.closest('.df-ad-close')){var box=e.target.closest('.df-ad-overlay');if(box)box.remove();}});</script>
<?php },30);


add_action('wp_head', function() {
    if (!is_singular('df_drama')) return;
    $id=get_queried_object_id();
    $title=get_post_meta($id,'_df_seo_title',true);
    $desc=get_post_meta($id,'_df_seo_description',true);
    if ($title) echo '<meta name="title" content="'.esc_attr($title).'">' . "\n";
    if ($desc) echo '<meta name="description" content="'.esc_attr($desc).'">' . "\n";
}, 2);

add_action('admin_post_df_gsc_connect','df_gsc_connect');
add_action('admin_post_df_gsc_callback','df_gsc_callback');
add_action('admin_post_df_gsc_disconnect','df_gsc_disconnect');
add_action('admin_menu', function(){
    add_menu_page('DramaFlow','DramaFlow','manage_options','dramaflow','df_admin_dashboard','dashicons-video-alt3',26);
    add_submenu_page('dramaflow','SEO Assistant','SEO Assistant','manage_options','df-seo','df_seo_page');
    add_submenu_page('dramaflow','Integrations','Integrations','manage_options','df-integrations','df_integrations_page');
    add_submenu_page('dramaflow','Affiliate Reports','Affiliate Reports','manage_options','df-affiliate-reports','df_affiliate_reports');
    add_submenu_page('dramaflow','Demo & Import','Demo & Import','manage_options','df-demo-import','df_demo_import_page');
});

function df_demo_import_page() {
    if (!current_user_can('manage_options')) return;
    $notice='';
    if (isset($_POST['df_install_demo'])) {
        check_admin_referer('df_install_demo_action');
        $created=df_install_demo_content();
        $notice='<div class="notice notice-success"><p>Dummy data berhasil dipasang: '.(int)$created['dramas'].' drama dan '.(int)$created['episodes'].' episode. Data yang sudah ada tidak digandakan.</p></div>';
    }
    if (isset($_POST['df_upload_json']) && !empty($_FILES['df_demo_json']['tmp_name'])) {
        check_admin_referer('df_upload_json_action');
        $raw=file_get_contents($_FILES['df_demo_json']['tmp_name']);
        $data=json_decode($raw,true);
        if (!is_array($data) || empty($data['dramas']) || !is_array($data['dramas'])) {
            $notice='<div class="notice notice-error"><p>File JSON tidak valid. Gunakan format contoh yang disediakan.</p></div>';
        } else {
            $created=df_import_json_dramas($data['dramas']);
            $notice='<div class="notice notice-success"><p>Import selesai: '.(int)$created['dramas'].' drama dan '.(int)$created['episodes'].' episode.</p></div>';
        }
    }
    echo '<div class="wrap"><h1>DramaFlow — Demo Data & Import</h1>'.$notice;
    echo '<p>Pasang konten contoh agar tampilan situs langsung terisi setelah instalasi. Konten demo menggunakan judul fiktif dan belum menyertakan video berhak cipta.</p>';
    echo '<form method="post">'; wp_nonce_field('df_install_demo_action');
    echo '<p><button class="button button-primary" name="df_install_demo" value="1">Pasang Dummy Data Sekarang</button></p></form>';
    echo '<hr><h2>Upload data drama dari JSON</h2><p>Siapkan file JSON mengikuti struktur contoh di bawah. Drama dan episode akan dibuat sebagai draft agar bisa diperiksa sebelum dipublikasikan.</p>';
    echo '<pre style="background:#fff;padding:14px;max-width:850px;overflow:auto">{"dramas":[{"title":"Judul Drama","synopsis":"Sinopsis singkat","year":"2026","country":"Korea Selatan","genre":["Romance","Drama"],"episodes":[{"title":"Episode 1","number":1,"video_url":""}]}]}</pre>';
    echo '<form method="post" enctype="multipart/form-data">'; wp_nonce_field('df_upload_json_action');
    echo '<input type="file" name="df_demo_json" accept=".json,application/json" required> <button class="button" name="df_upload_json" value="1">Upload & Import JSON</button></form>';
    echo '<p><strong>Catatan:</strong> import JSON membuat drama dan episode sebagai draft. Pasang Dummy Data membuat contoh yang langsung tampil di katalog. Tidak menghapus konten yang sudah ada.</p></div>';
}
function df_install_demo_content() {
    $items=[
      ['The Last Promise','Seorang jurnalis menemukan rahasia keluarga yang mengubah hidupnya.','2026','Korea Selatan',['Drama','Mystery']],
      ['Moonlight Love','Dua orang asing bertemu kembali di kota pesisir yang tenang.','2025','Jepang',['Romance']],
      ['Shadow City','Detektif muda menyelidiki rangkaian kasus di kota futuristik.','2026','Thailand',['Action','Thriller']],
      ['Winter Letter','Sepucuk surat lama membuka kisah persahabatan dan kehilangan.','2024','Korea Selatan',['Romance','Drama']]
    ];
    $created=['dramas'=>0,'episodes'=>0];
    foreach($items as $item) {
      $existing=get_page_by_title($item[0],OBJECT,'df_drama');
      if($existing) continue;
      $id=wp_insert_post(['post_type'=>'df_drama','post_status'=>'publish','post_title'=>$item[0],'post_excerpt'=>$item[1],'post_content'=>$item[1]]);
      if(is_wp_error($id)||!$id) continue;
      update_post_meta($id,'_df_year',$item[2]); update_post_meta($id,'_df_country',$item[3]);
      update_post_meta($id,'_df_seo_title',$item[0].' — DramaFlow');
      update_post_meta($id,'_df_seo_description',$item[1]);
      foreach($item[4] as $genre) { $term=term_exists($genre,'df_genre'); if(!$term) $term=wp_insert_term($genre,'df_genre'); if(!is_wp_error($term)) wp_set_object_terms($id,[$genre],'df_genre',true); }
      wp_set_object_terms($id,[$item[3]],'df_country',true);
      $created['dramas']++;
      for($n=1;$n<=3;$n++) {
        $ep=wp_insert_post(['post_type'=>'df_episode','post_status'=>'publish','post_title'=>$item[0].' — Episode '.$n,'post_content'=>'Episode contoh. Tambahkan URL video milik Anda melalui kolom Episode & Video.']);
        if(!is_wp_error($ep)&&$ep) { update_post_meta($ep,'_df_drama_id',$id); update_post_meta($ep,'_df_episode_number',$n); $created['episodes']++; }
      }
    }
    update_option('df_demo_data_installed',1);
    return $created;
}
function df_import_json_dramas($items) {
    $created=['dramas'=>0,'episodes'=>0];
    foreach(array_slice($items,0,100) as $item) {
      if(empty($item['title'])) continue;
      $id=wp_insert_post(['post_type'=>'df_drama','post_status'=>'draft','post_title'=>sanitize_text_field($item['title']),'post_content'=>sanitize_textarea_field($item['synopsis']??'')]);
      if(is_wp_error($id)||!$id) continue;
      if(!empty($item['year'])) update_post_meta($id,'_df_year',sanitize_text_field($item['year']));
      if(!empty($item['country'])) update_post_meta($id,'_df_country',sanitize_text_field($item['country']));
      if(!empty($item['genre'])&&is_array($item['genre'])) foreach(array_slice($item['genre'],0,10) as $g) wp_set_object_terms($id,sanitize_text_field($g),'df_genre',true);
      $created['dramas']++;
      if(!empty($item['episodes'])&&is_array($item['episodes'])) foreach(array_slice($item['episodes'],0,100) as $e) {
        if(empty($e['title'])) continue;
        $ep=wp_insert_post(['post_type'=>'df_episode','post_status'=>'draft','post_title'=>sanitize_text_field($e['title'])]);
        if(!is_wp_error($ep)&&$ep) { update_post_meta($ep,'_df_drama_id',$id); update_post_meta($ep,'_df_episode_number',absint($e['number']??1)); if(!empty($e['video_url'])) update_post_meta($ep,'_df_video_url',esc_url_raw($e['video_url'])); $created['episodes']++; }
      }
    }
    return $created;
}
function df_admin_dashboard() {
    if (!current_user_can('manage_options')) return;
    global $wpdb; $table=$wpdb->prefix.'df_affiliate_clicks';
    $count=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
    $dramas=wp_count_posts('df_drama'); $episodes=wp_count_posts('df_episode');
    echo '<div class="wrap"><h1>DramaFlow Dashboard</h1><p>Kelola streaming dan monetisasi affiliate dari satu dashboard.</p><div style="display:flex;gap:16px;flex-wrap:wrap"><div class="card"><h2>'.esc_html((int)$dramas->publish).'</h2><p>Drama published</p></div><div class="card"><h2>'.esc_html((int)$episodes->publish).'</h2><p>Episode published</p></div><div class="card"><h2>'.esc_html($count).'</h2><p>Total affiliate clicks</p></div></div><p><a class="button button-primary" href="'.esc_url(admin_url('post-new.php?post_type=df_drama')).'">Tambah Drama</a> <a class="button" href="'.esc_url(admin_url('post-new.php?post_type=df_episode')).'">Tambah Episode</a> <a class="button" href="'.esc_url(admin_url('post-new.php?post_type=df_player_ad')).'">Buat Kampanye Iklan</a></p></div>';
}
function df_affiliate_reports() {
    if (!current_user_can('manage_options')) return;
    global $wpdb; $table=$wpdb->prefix.'df_affiliate_clicks';
    $rows=$wpdb->get_results("SELECT ad_id,
        SUM(CASE WHEN event_type='impression' THEN 1 ELSE 0 END) impressions,
        SUM(CASE WHEN event_type='click' THEN 1 ELSE 0 END) clicks,
        MAX(clicked_at) last_event
        FROM $table GROUP BY ad_id ORDER BY clicks DESC");
    echo '<div class="wrap"><h1>Affiliate Reports</h1><p>Impression dihitung saat materi iklan dirender pada halaman episode; klik dicatat saat pengunjung membuka tautan. CTR adalah klik dibagi impression, bukan data penjualan atau komisi marketplace.</p><table class="widefat striped"><thead><tr><th>Kampanye</th><th>Impression</th><th>Klik</th><th>CTR</th><th>Aktivitas terakhir</th></tr></thead><tbody>';
    if ($rows) foreach($rows as $r) {
        $ctr=((int)$r->impressions)>0?round(((int)$r->clicks/(int)$r->impressions)*100,2):0;
        echo '<tr><td><a href="'.esc_url(get_edit_post_link($r->ad_id)).'">'.esc_html(get_the_title($r->ad_id) ?: 'Campaign #'.(int)$r->ad_id).'</a></td><td>'.esc_html((int)$r->impressions).'</td><td>'.esc_html((int)$r->clicks).'</td><td>'.esc_html($ctr).'%</td><td>'.esc_html($r->last_event).'</td></tr>';
    } else echo '<tr><td colspan="5">Belum ada aktivitas.</td></tr>';
    echo '</tbody></table></div>';
}
function df_seo_suggest($post_id) {
    $post=get_post($post_id);
    if (!$post || $post->post_type!=='df_drama') return ['title'=>'','description'=>''];
    $title=trim(wp_strip_all_tags($post->post_title));
    $excerpt=trim(wp_strip_all_tags($post->post_excerpt ?: $post->post_content));
    $excerpt=wp_trim_words($excerpt,24,'');
    $terms=wp_get_post_terms($post_id,'df_genre',['fields'=>'names']);
    $genre=$terms && !is_wp_error($terms)?implode(', ',array_slice($terms,0,2)):'drama';
    $country=get_post_meta($post_id,'_df_country',true);
    $year=get_post_meta($post_id,'_df_year',true);
    $seo_title=$title.' – Nonton '.$genre;
    if($country) $seo_title.=' '.$country;
    if($year) $seo_title.=' '.$year;
    $seo_title=wp_html_excerpt($seo_title,60,'');
    $description=$excerpt ?: ('Kenali '.$title.', '.$genre.($country?' dari '.$country:'').'. Lihat sinopsis dan daftar episode di DramaFlow.');
    $description=wp_html_excerpt($description,155,'…');
    return ['title'=>$seo_title,'description'=>$description];
}
function df_seo_page() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['df_apply_seo'])) {
        check_admin_referer('df_apply_seo_action');
        $id=absint($_POST['df_post_id'] ?? 0);
        if ($id && current_user_can('edit_post',$id) && get_post_type($id)==='df_drama') {
            $suggest=df_seo_suggest($id);
            update_post_meta($id,'_df_seo_title',$suggest['title']);
            update_post_meta($id,'_df_seo_description',$suggest['description']);
            echo '<div class="notice notice-success"><p>SEO title dan description disimpan. Kamu masih bisa mengubahnya di editor drama.</p></div>';
        }
    }
    $dramas=get_posts(['post_type'=>'df_drama','post_status'=>'publish','numberposts'=>-1]);
    $missing=[];
    foreach($dramas as $d) {
        if (!get_post_meta($d->ID,'_df_seo_title',true) || !get_post_meta($d->ID,'_df_seo_description',true)) $missing[]=$d;
    }
    echo '<div class="wrap"><h1>DramaFlow SEO Assistant</h1><p>Asisten membuat draft SEO lokal dari judul, sinopsis, genre, negara, dan tahun. Tidak ada perubahan diterapkan sampai admin menekan tombol Terapkan.</p>';
    echo '<div class="notice notice-info"><p>Rekomendasi ini berbasis template dan data konten WordPress, bukan hasil riset volume keyword. Integrasi Search Console API dan AI eksternal belum tersedia.</p></div>';
    echo '<p><strong>'.count($dramas).'</strong> drama diterbitkan · <strong>'.count($missing).'</strong> membutuhkan metadata SEO.</p>';
    echo '<table class="widefat striped"><thead><tr><th>Drama</th><th>Draft SEO Title</th><th>Draft Meta Description</th><th>Persetujuan</th></tr></thead><tbody>';
    foreach($missing as $d) {
        $suggest=df_seo_suggest($d->ID);
        echo '<tr><td><a href="'.esc_url(get_edit_post_link($d->ID)).'">'.esc_html($d->post_title).'</a></td><td>'.esc_html($suggest['title']).'</td><td>'.esc_html($suggest['description']).'</td><td><form method="post">';
        wp_nonce_field('df_apply_seo_action');
        echo '<input type="hidden" name="df_post_id" value="'.(int)$d->ID.'"><button class="button button-primary" name="df_apply_seo" value="1">Terapkan</button></form></td></tr>';
    }
    if(!$missing) echo '<tr><td colspan="4">Semua drama sudah memiliki SEO title dan description.</td></tr>';
    echo '</tbody></table>';
    if (!empty($_GET['gsc_refresh']) && get_option('df_gsc_refresh_token','')) {
        $sites=df_gsc_sites();
        if (is_wp_error($sites)) echo '<div class="notice notice-error"><p>'.esc_html($sites->get_error_message()).'</p></div>';
        elseif (!$sites) echo '<p>Belum ada properti Search Console yang dapat diakses akun ini.</p>';
        else {
            $site=home_url('/');
            $chosen='';
            foreach($sites as $entry) if(!empty($entry['siteUrl']) && untrailingslashit($entry['siteUrl'])===untrailingslashit($site)) {$chosen=$entry['siteUrl'];break;}
            if(!$chosen) $chosen=$sites[0]['siteUrl'];
            $end=gmdate('Y-m-d',strtotime('-3 days')); $begin=gmdate('Y-m-d',strtotime('-31 days'));
            $rows=df_gsc_query($chosen,$begin,$end);
            echo '<h2>Search Console: '.esc_html($chosen).'</h2><p>Periode '.esc_html($begin).' sampai '.esc_html($end).'.</p>';
            if(is_wp_error($rows)) echo '<div class="notice notice-error"><p>'.esc_html($rows->get_error_message()).'</p></div>';
            else {
                echo '<table class="widefat striped"><thead><tr><th>Query</th><th>Clicks</th><th>Impressions</th><th>CTR</th><th>Position</th></tr></thead><tbody>';
                foreach($rows as $row) { $keys=$row['keys']??[]; echo '<tr><td>'.esc_html($keys[0]??'').'</td><td>'.esc_html((int)($row['clicks']??0)).'</td><td>'.esc_html((int)($row['impressions']??0)).'</td><td>'.esc_html(round(($row['ctr']??0)*100,2)).'%</td><td>'.esc_html(round($row['position']??0,1)).'</td></tr>'; }
                if(!$rows) echo '<tr><td colspan="5">Belum ada data untuk periode ini.</td></tr>';
                echo '</tbody></table>';
                $opportunities=[];
                foreach($rows as $row) {
                    $query=$row['keys'][0]??'';
                    $impressions=(int)($row['impressions']??0);
                    $clicks=(int)($row['clicks']??0);
                    $ctr=(float)($row['ctr']??0);
                    $position=(float)($row['position']??0);
                    if($impressions>=50 && $ctr<0.02) {
                        $opportunities[]=['query'=>$query,'reason'=>'Impressions relatif tinggi tetapi CTR di bawah 2%.','action'=>'Tinjau kecocokan SEO title dan meta description dengan maksud pencarian.'];
                    } elseif($impressions>=30 && $position>=4 && $position<=20) {
                        $opportunities[]=['query'=>$query,'reason'=>'Posisi rata-rata berada di kisaran 4–20.','action'=>'Periksa kelengkapan sinopsis, heading, internal link, dan relevansi halaman.'];
                    } elseif($impressions<10 && $position>20) {
                        $opportunities[]=['query'=>$query,'reason'=>'Visibilitas pencarian masih rendah.','action'=>'Periksa apakah halaman sudah terindeks dan kontennya menjawab kebutuhan pencarian.'];
                    }
                }
                echo '<h3>Peluang optimasi berdasarkan data</h3><p>Ambang ini adalah heuristik awal, bukan jaminan kenaikan ranking.</p><table class="widefat striped"><thead><tr><th>Query</th><th>Temuan</th><th>Saran tindakan</th></tr></thead><tbody>';
                if($opportunities) foreach(array_slice($opportunities,0,15) as $opp) echo '<tr><td>'.esc_html($opp['query']).'</td><td>'.esc_html($opp['reason']).'</td><td>'.esc_html($opp['action']).'</td></tr>';
                else echo '<tr><td colspan="3">Belum ada peluang yang memenuhi ambang heuristik. Periksa kembali setelah data lebih banyak terkumpul.</td></tr>';
                echo '</tbody></table>';

                $page_rows=df_gsc_query($chosen,$begin,$end,['page']);
                echo '<h3>Performa halaman</h3><p>Halaman dengan impressions tinggi dan CTR rendah layak diperiksa lebih dulu.</p><table class="widefat striped"><thead><tr><th>URL halaman</th><th>Clicks</th><th>Impressions</th><th>CTR</th><th>Posisi</th><th>Prioritas</th></tr></thead><tbody>';
                if(is_wp_error($page_rows)) {
                    echo '<tr><td colspan="6">'.esc_html($page_rows->get_error_message()).'</td></tr>';
                } elseif($page_rows) {
                    foreach($page_rows as $pr) {
                        $url=$pr['keys'][0]??'';
                        $imp=(int)($pr['impressions']??0); $ctr=(float)($pr['ctr']??0); $pos=(float)($pr['position']??0);
                        $priority=($imp>=50 && $ctr<0.02)?'Tinggi':(($pos>=4 && $pos<=20 && $imp>=30)?'Sedang':'Pantau');
                        echo '<tr><td><a href="'.esc_url($url).'" target="_blank" rel="noopener">'.esc_html($url).'</a></td><td>'.(int)($pr['clicks']??0).'</td><td>'.$imp.'</td><td>'.round($ctr*100,2).'%</td><td>'.round($pos,1).'</td><td>'.esc_html($priority).'</td></tr>';
                    }
                } else echo '<tr><td colspan="6">Belum ada data performa halaman.</td></tr>';
                echo '</tbody></table>';

                global $wpdb;
                $click_table=$wpdb->prefix.'df_affiliate_clicks';
                $affiliate_pages=$wpdb->get_results($wpdb->prepare(
                    "SELECT referer, COUNT(*) AS clicks FROM $click_table WHERE event_type=%s AND clicked_at >= %s GROUP BY referer ORDER BY clicks DESC LIMIT 20",
                    'click', gmdate('Y-m-d H:i:s',strtotime('-30 days'))
                ));
                echo '<h3>Halaman dengan klik affiliate terbanyak</h3><p>Data ini berasal dari klik yang tercatat di DramaFlow, bukan transaksi atau komisi marketplace.</p><table class="widefat striped"><thead><tr><th>Referer</th><th>Klik affiliate</th></tr></thead><tbody>';
                if($affiliate_pages) foreach($affiliate_pages as $ap) echo '<tr><td>'.esc_html($ap->referer?:'(referer tidak tersedia)').'</td><td>'.(int)$ap->clicks.'</td></tr>';
                else echo '<tr><td colspan="2">Belum ada klik affiliate yang tercatat.</td></tr>';
                echo '</tbody></table>';
            }
        }
    }
    echo '</div>';
}
function df_integrations_page() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['df_save_integrations'])) {
        check_admin_referer('df_integrations_save');
        $ga=isset($_POST['df_ga4_id'])?sanitize_text_field(wp_unslash($_POST['df_ga4_id'])):'';
        $gsc=isset($_POST['df_gsc_code'])?sanitize_text_field(wp_unslash($_POST['df_gsc_code'])):'';
        $client=isset($_POST['df_gsc_client_id'])?sanitize_text_field(wp_unslash($_POST['df_gsc_client_id'])):'';
        $secret=isset($_POST['df_gsc_client_secret'])?sanitize_text_field(wp_unslash($_POST['df_gsc_client_secret'])):'';
        if ($ga && !preg_match('/^G-[A-Z0-9]+$/i',$ga)) $ga='';
        update_option('df_ga4_id',$ga);
        update_option('df_gsc_code',$gsc);
        update_option('df_gsc_client_id',$client);
        if ($secret!=='') update_option('df_gsc_client_secret',$secret);
        echo '<div class="notice notice-success"><p>Pengaturan integrasi disimpan.</p></div>';
    }
    $ga=get_option('df_ga4_id',''); $gsc=get_option('df_gsc_code','');
    $client=get_option('df_gsc_client_id',''); $connected=(bool)get_option('df_gsc_refresh_token','');
    $redirect=admin_url('admin-post.php?action=df_gsc_callback');
    echo '<div class="wrap"><h1>Integrasi Google</h1><form method="post">';
    wp_nonce_field('df_integrations_save');
    echo '<table class="form-table"><tr><th><label for="df_ga4_id">Google Analytics 4 Measurement ID</label></th><td><input class="regular-text" id="df_ga4_id" name="df_ga4_id" value="'.esc_attr($ga).'" placeholder="G-XXXXXXXXXX"><p class="description">Memasang GA4 page_view dan event affiliate_click.</p></td></tr>';
    echo '<tr><th><label for="df_gsc_code">Search Console verification code</label></th><td><input class="regular-text" id="df_gsc_code" name="df_gsc_code" value="'.esc_attr($gsc).'"></td></tr>';
    echo '<tr><th><label for="df_gsc_client_id">Google OAuth Client ID</label></th><td><input class="regular-text" id="df_gsc_client_id" name="df_gsc_client_id" value="'.esc_attr($client).'"><p class="description">Buat OAuth Client ID tipe Web application di Google Cloud Console.</p></td></tr>';
    echo '<tr><th><label for="df_gsc_client_secret">Google OAuth Client Secret</label></th><td><input class="regular-text" type="password" id="df_gsc_client_secret" name="df_gsc_client_secret" value="" autocomplete="new-password"><p class="description">Kosongkan untuk mempertahankan secret tersimpan. Redirect URI: <code>'.esc_html($redirect).'</code></p></td></tr></table>';
    submit_button('Simpan Pengaturan','primary','df_save_integrations'); echo '</form><hr><h2>Google Search Console API</h2>';
    echo '<p>Status koneksi: <strong>'.($connected?'Terhubung':'Belum terhubung').'</strong></p>';
    if($connected) {
        echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=df-seo&gsc_refresh=1')).'">Lihat data Search Console</a></p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="df_gsc_disconnect">';
        wp_nonce_field('df_gsc_disconnect'); submit_button('Putuskan koneksi','secondary'); echo '</form>';
    } else {
        echo '<p>Setelah menyimpan Client ID dan Secret, hubungkan akun Google yang memiliki akses ke properti Search Console.</p>';
        echo '<a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=df_gsc_connect'),'df_gsc_connect')).'">Hubungkan Search Console</a>';
    }
    echo '<p class="description">Data yang diambil adalah performa pencarian website. Simpan kredensial dengan aman dan berikan akses hanya kepada admin tepercaya.</p></div>';
}
function df_gsc_connect() {
    if (!current_user_can('manage_options') || !check_admin_referer('df_gsc_connect')) wp_die('Akses tidak diizinkan.');
    $client=get_option('df_gsc_client_id','');
    if (!$client || !get_option('df_gsc_client_secret','')) wp_die('Isi OAuth Client ID dan Client Secret terlebih dahulu.');
    $state=wp_generate_password(32,false,false);
    set_transient('df_gsc_state_'.get_current_user_id(),$state,10*MINUTE_IN_SECONDS);
    $url=add_query_arg([
        'client_id'=>$client,'redirect_uri'=>admin_url('admin-post.php?action=df_gsc_callback'),
        'response_type'=>'code','scope'=>'https://www.googleapis.com/auth/webmasters.readonly',
        'access_type'=>'offline','prompt'=>'consent','state'=>$state
    ],'https://accounts.google.com/o/oauth2/v2/auth');
    wp_safe_redirect($url); exit;
}
function df_gsc_callback() {
    if (!current_user_can('manage_options')) wp_die('Akses tidak diizinkan.');
    $state=isset($_GET['state'])?sanitize_text_field(wp_unslash($_GET['state'])):'';
    $saved=get_transient('df_gsc_state_'.get_current_user_id());
    delete_transient('df_gsc_state_'.get_current_user_id());
    if (!$saved || !hash_equals($saved,$state)) wp_die('State OAuth tidak valid. Silakan coba hubungkan ulang.');
    if (!empty($_GET['error'])) wp_die('Google menolak atau membatalkan otorisasi.');
    $code=isset($_GET['code'])?sanitize_text_field(wp_unslash($_GET['code'])):'';
    $response=wp_remote_post('https://oauth2.googleapis.com/token',['timeout'=>20,'body'=>[
        'code'=>$code,'client_id'=>get_option('df_gsc_client_id',''),
        'client_secret'=>get_option('df_gsc_client_secret',''),
        'redirect_uri'=>admin_url('admin-post.php?action=df_gsc_callback'),
        'grant_type'=>'authorization_code'
    ]]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response)!==200) wp_die('Gagal menukar kode OAuth. Periksa Client ID, Secret, dan Redirect URI.');
    $data=json_decode(wp_remote_retrieve_body($response),true);
    if (empty($data['refresh_token'])) wp_die('Google tidak memberikan refresh token. Cabut akses aplikasi di akun Google lalu coba hubungkan ulang dengan consent.');
    update_option('df_gsc_refresh_token',sanitize_text_field($data['refresh_token']));
    if (!empty($data['access_token'])) update_option('df_gsc_access_token',sanitize_text_field($data['access_token']));
    if (!empty($data['expires_in'])) update_option('df_gsc_token_expires',time()+absint($data['expires_in']));
    wp_safe_redirect(admin_url('admin.php?page=df-integrations&gsc_connected=1')); exit;
}
function df_gsc_disconnect() {
    if (!current_user_can('manage_options') || !check_admin_referer('df_gsc_disconnect')) wp_die('Akses tidak diizinkan.');
    delete_option('df_gsc_refresh_token'); delete_option('df_gsc_access_token'); delete_option('df_gsc_token_expires');
    wp_safe_redirect(admin_url('admin.php?page=df-integrations')); exit;
}
function df_gsc_access_token() {
    $token=get_option('df_gsc_access_token',''); $expires=(int)get_option('df_gsc_token_expires',0);
    if ($token && $expires>time()+60) return $token;
    $refresh=get_option('df_gsc_refresh_token','');
    if (!$refresh) return new WP_Error('df_gsc_not_connected','Search Console belum terhubung.');
    $response=wp_remote_post('https://oauth2.googleapis.com/token',['timeout'=>20,'body'=>[
        'client_id'=>get_option('df_gsc_client_id',''),'client_secret'=>get_option('df_gsc_client_secret',''),
        'refresh_token'=>$refresh,'grant_type'=>'refresh_token'
    ]]);
    if (is_wp_error($response)) return $response;
    $data=json_decode(wp_remote_retrieve_body($response),true);
    if (wp_remote_retrieve_response_code($response)!==200 || empty($data['access_token'])) return new WP_Error('df_gsc_token_failed','Gagal memperbarui token Search Console.');
    update_option('df_gsc_access_token',sanitize_text_field($data['access_token']));
    update_option('df_gsc_token_expires',time()+absint($data['expires_in']??3600));
    return $data['access_token'];
}
function df_gsc_sites() {
    $token=df_gsc_access_token(); if(is_wp_error($token)) return $token;
    $res=wp_remote_get('https://www.googleapis.com/webmasters/v3/sites',['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$token]]);
    if(is_wp_error($res)) return $res;
    $data=json_decode(wp_remote_retrieve_body($res),true);
    if(wp_remote_retrieve_response_code($res)!==200) return new WP_Error('df_gsc_sites_failed','Tidak dapat membaca daftar properti Search Console.');
    return $data['siteEntry']??[];
}
function df_gsc_query($site,$start,$end,$dimensions=['query']) {
    $token=df_gsc_access_token(); if(is_wp_error($token)) return $token;
    $url='https://www.googleapis.com/webmasters/v3/sites/'.rawurlencode($site).'/searchAnalytics/query';
    $res=wp_remote_post($url,['timeout'=>30,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode([
        'startDate'=>$start,'endDate'=>$end,'dimensions'=>array_values($dimensions),'rowLimit'=>100
    ])]);
    if(is_wp_error($res)) return $res;
    $data=json_decode(wp_remote_retrieve_body($res),true);
    if(wp_remote_retrieve_response_code($res)!==200) return new WP_Error('df_gsc_query_failed',$data['error']['message']??'Search Analytics API gagal.');
    return $data['rows']??[];
}

add_action('wp_head',function(){
    $gsc=get_option('df_gsc_code','');
    if($gsc) echo '<meta name="google-site-verification" content="'.esc_attr($gsc).'">'."\\n";
    $ga=get_option('df_ga4_id','');
    if($ga && preg_match('/^G-[A-Z0-9]+$/i',$ga)) {
        echo '<script async src="https://www.googletagmanager.com/gtag/js?id='.esc_attr($ga).'"></script>'."\\n";
        echo '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config","'.esc_js($ga).'");</script>'."\\n";
    }
},1);
add_action('wp_footer',function(){
    if(!get_option('df_ga4_id','')) return;
    ?>
    <script>
    document.addEventListener('click',function(e){
      var link=e.target.closest('.df-ad-overlay a');
      if(!link || typeof window.gtag!=='function') return;
      window.gtag('event','affiliate_click',{campaign_link:link.href,placement:'video_player'});
    });
    </script>
    <?php
},40);
